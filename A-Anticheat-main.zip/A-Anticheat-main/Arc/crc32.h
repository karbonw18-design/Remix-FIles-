#pragma once
#include "pch.h"

uint32_t crc32(const void* M, uint32_t bytes, uint32_t prev /* = 0*/);
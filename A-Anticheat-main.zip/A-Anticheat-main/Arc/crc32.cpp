#include "pch.h"
#include <isa_availability.h>

static constexpr uint32_t P = 0x82f63b78U;

static constexpr uint64_t g_lut_intel[] = {
    0x00000001493c7d27,
    0x493c7d27ba4fc28e,
    0xf20c0dfeddc0152b,
    0xba4fc28e9e4addf8,
    0x3da6d0cb39d3b296,
    0xddc0152b0715ce53,
    0x1c291d0447db8317,
    0x9e4addf80d3b6092,
    0x740eef02c96cfdc0,
    0x39d3b296878a92a7,
    0x083a6eecdaece73e,
    0x0715ce53ab7aff2a,
    0xc49f4f672162d385,
    0x47db831783348832,
    0x2ad91c30299847d5,
    0x0d3b6092b9e02b86,
    0x6992cea218b33a4e,
    0xc96cfdc0b6dd949b,
    0x7e90804878d9ccb7,
    0x878a92a7bac2fd7b,
    0x1b3d8f29a60ce07b,
    0xdaece73ece7f39f4,
    0xf1d0f55e61d82e56,
    0xab7aff2ad270f1a2,
    0xa87ab8a8c619809d,
    0x2162d3852b3cac5d,
    0x8462d80065863b64,
    0x833488321b03397f,
    0x71d111a8ebb883bd,
    0x299847d5b3e32c28,
    0xffd852c6064f7f26,
    0xb9e02b86dd7e3b0c,
    0xdcb17aa4f285651c,
    0x18b33a4e10746f3c,
    0xf37c5aeec7a68855,
    0xb6dd949b271d9844,
    0x6051d5a28e766a0c,
    0x78d9ccb793a5f730,
    0x18b0d4ff6cb08e5c,
    0xbac2fd7b6b749fb2,
    0x21f3d99c1393e203,
    0xa60ce07bcec3662e,
    0x8f15801496c515bb,
    0xce7f39f4e6fc4e6a,
    0xa00457f78227bb8a,
    0x61d82e56b0cd4768,
    0x8d6d2c4339c7ff35,
    0xd270f1a2d7a4825c,
    0x00ac29cf0ab3844b,
    0xc619809d0167d312,
    0xe9adf796f6076544,
    0x2b3cac5d26f6a60a,
    0x96638b34a741c1bf,
    0x65863b6498d8d9cb,
    0xe0e9f35149c3cc9c,
    0x1b03397f68bce87a,
    0x9af01f2d57a3d037,
    0xebb883bd6956fc3b,
    0x2cff42cf42d98888,
    0xb3e32c283771e98f,
    0x88f25a3ab42ae3d9,
    0x064f7f262178513a,
    0x4e36f0b0e0ac139e,
    0xdd7e3b0c170076fa,
    0xbd6f81f8444dd413,
    0xf285651c6f345e45,
    0x91c9bd4b41d17b64,
    0x10746f3cff0dba97,
    0x885f087ba2b73df1,
    0xc7a68855f872e54c,
    0x4c1449321e41e9fc,
    0x271d984486d8e4d2,
    0x52148f02651bd98b,
    0x8e766a0c5bb8f1bc,
    0xa3c6f37aa90fd27a,
    0x93a5f730b3af077a,
    0xd7c0557f4984d782,
    0x6cb08e5cca6ef3ac,
    0x63ded06a234e0b26,
    0x6b749fb2dd66cbbb,
    0x4d56973c4597456a,
    0x1393e203e9e28eb4,
    0x9669c9df7b3ff57a,
    0xcec3662ec9c8b782,
    0xe417f38a3f70cc6f,
    0x96c515bb93e106a4,
    0x4b9e0f7162ec6c6d,
    0xe6fc4e6ad813b325,
    0xd104b8fc0df04680,
    0x8227bb8a2342001e,
    0x5b3977300a2a8d7e,
    0xb0cd47686d9a4957,
    0xe78eb416e8b6368b,
    0x39c7ff35d2c3ed1a,
    0x61ff0e01995a5724,
    0xd7a4825c9ef68d35,
    0x8d96551c0c139b31,
    0x0ab3844bf2271e60,
    0x0bf80dd20b0bf8ca,
    0x0167d3122664fd8b,
    0x8821abeded64812d,
    0xf607654402ee03b2,
    0x6a45d2b28604ae0f,
    0x26f6a60a363bd6b3,
    0xd8d26619135c83fd,
    0xa741c1bf5fabe670,
    0xde87806c35ec3279,
    0x98d8d9cb00bcf5f6,
    0x143387548ae00689,
    0x49c3cc9c17f27698,
    0x5bd2011f58ca5f00,
    0x68bce87aaa7c7ad5,
    0xdd07448eb5cfca28,
    0x57a3d037ded288f8,
    0xdde8f5b959f229bc,
    0x6956fc3b6d390dec,
    0xa3e3e02c37170390,
    0x42d988886353c1cc,
    0xd73c7beac4584f5c,
    0x3771e98ff48642e9,
    0x80ff0093531377e2,
    0xb42ae3d9dd35bc8d,
    0x8fe4c34db25b29f2,
    0x2178513a9a5ede41,
    0xdf99fc11a563905d,
    0xe0ac139e45cddf4e,
    0x6c23e841acfa3103,
    0x170076faa51b6135,
    0xfe314258dfd94fb2,
    0x444dd41380f2886b,
    0x0d8373a067969a6a,
    0x6f345e45021ac5ef,
    0x19e3635ee8310afa,
    0x41d17b6475451b04,
    0x29f268b48e1450f7,
    0xff0dba97cbbe4ee1,
    0x1dc0632a3a83de21,
    0xa2b73df1e0cdcf86,
    0x1614f396453c1679,
    0xf872e54cdefba41c,
    0x9e2993d3613eee91,
    0x1e41e9fcddaf5114,
    0x6bebd73c1f1dd124,
    0x86d8e4d2bedc6ba1,
    0x63ae91e6eca08ffe,
    0x651bd98b3ae30875,
    0xf8c9da7a0cd1526a,
    0x5bb8f1bcb1630f04,
    0x945a19c1ff47317b,
    0xa90fd27ad6c3a807,
    0xee8213b79a7781e0,
    0xb3af077a63d097e9,
    0x93781dc71d31175f,
    0x4984d78294eb256e,
    0xccc4a1b913184649,
    0xca6ef3ac4be7fd90,
    0xa2c2d9717d5c1d64,
    0x234e0b2680ba859a,
    0x1cad44526eeed1c9,
    0xdd66cbbb22c3799f,
    0x74922601d8ecc578,
    0x4597456ab3a6da94,
    0xc55f7eabcaf933fe,
    0xe9e28eb450bfaade,
    0xa19623292e7d11a7,
    0x7b3ff57a7d14748f,
    0x2d37074932d8041c,
    0xc9c8b782889774e1,
    0x397d84a16cc8a0ff,
    0x3f70cc6f5aa1f3cf,
    0x791132708a074012,
    0x93e106a433bc58b3,
    0xbc8178039f2b002a,
    0x62ec6c6dbd0bb25f,
    0x88eb3c0760bf0a6a,
    0xd813b3258515c07f,
    0x6e4cb6303be3c09b,
    0x0df04680d8440525,
    0x71971d5c682d085d,
    0x2342001e465a4eee,
    0xf33b8bc628b5de82,
    0x0a2a8d7e077d54e0,
    0x9fb3bbc02e5f3c8c,
    0x6d9a4957c00df280,
    0x6ef22b23d0a37f43,
    0xe8b6368ba52f58ec,
    0xce2df76800712e86,
    0xd2c3ed1ad6748e82,
    0xe53a4fc747972100,
    0x995a572451aeef66,
    0xbe60a91a71900712,
    0x9ef68d35359674f7,
    0x1dfa0a15647fbd15,
    0x0c139b311baaa809,
    0x8ec52396469aef86,
    0xf2271e6086d42d06,
    0x0e766b114aba1470,
    0x0b0bf8ca1c2cce0a,
    0x475846a4aa0cd2d3,
    0x2664fd8bf8448640,
    0xb2a3dfa6ac4fcdec,
    0xed64812de81cf154,
    0xdc1a160cc2c7385c,
    0x02ee03b295ffd7dc,
    0x79afdf1c91de6176,
    0x8604ae0f84ee89ac,
    0x07ac6e46533e308d,
    0x363bd6b35f0e0438,
    0x15f85253604d6e09,
    0x135c83fdaeb3e622,
    0x1bec24dd4263eb04,
    0x5fabe67050c2cb16,
    0x4c36cd5b6667afe7,
    0x35ec32791a6889b8,
    0xe0a22e29de42c92a,
    0x00bcf5f67f47463d,
    0x7c2b6ed9b82b6080,
    0x8ae00689828d550b,
    0x06ff88fddca2b4da,
    0x17f276984ac726eb,
    0xf7317cf0529295e6,
    0x58ca5f005e9f28eb,
    0x61b6e40b40c14fff,
    0xaa7c7ad596a1f19b,
    0xde8a97f8997157e1,
    0xb5cfca28b0ed8196,
    0x88f61445097e41e6,
    0xded288f84ce8bfe5,
    0xd4520e9ee36841ad,
    0x59f229bcd1a9427c,
    0x0c592bd593f3319c,
    0x6d390decb58ac6fe,
    0x38edfaf3e3809241,
    0x37170390f22fd3e2,
    0x72cbfcdb83c2df88,
    0x6353c1ccd6b1825a,
    0x348331a54e4ff232,
    0xc4584f5c6664d9c1,
    0xc3977c19836b5a6e,
    0xf48642e923d5e7e5,
    0xdafaea7c65065343,
    0x531377e21495d20d,
    0x73db4c04a29c82eb,
    0xdd35bc8df370b37f,
    0x72675ce8ea6dd7dc,
    0xb25b29f2e9415bce,
    0x3ec2ff8396309b0f,
    0x9a5ede41c776b648,
    0xe8c7a017c22c52c5,
    0xa563905dcecfcd43,
    0xcf4bfaefd8311ee7,
    0x45cddf4e24e6fe8f,
    0x6bde1ac7d0c6d7c9,
    0xacfa310345aa5d4a,
    0xae1175c2cf067065,
    0xa51b613582f89c77,
};

static constexpr uint32_t g_tbl[] = { 0x00000000, 0xf26b8303, 0xe13b70f7, 0x1350f3f4, 0xc79a971f, 0x35f1141c, 0x26a1e7e8, 0xd4ca64eb, 0x8ad958cf, 0x78b2dbcc, 0x6be22838,
    0x9989ab3b, 0x4d43cfd0, 0xbf284cd3, 0xac78bf27, 0x5e133c24, 0x105ec76f, 0xe235446c, 0xf165b798, 0x030e349b, 0xd7c45070, 0x25afd373, 0x36ff2087, 0xc494a384, 0x9a879fa0,
    0x68ec1ca3, 0x7bbcef57, 0x89d76c54, 0x5d1d08bf, 0xaf768bbc, 0xbc267848, 0x4e4dfb4b, 0x20bd8ede, 0xd2d60ddd, 0xc186fe29, 0x33ed7d2a, 0xe72719c1, 0x154c9ac2, 0x061c6936,
    0xf477ea35, 0xaa64d611, 0x580f5512, 0x4b5fa6e6, 0xb93425e5, 0x6dfe410e, 0x9f95c20d, 0x8cc531f9, 0x7eaeb2fa, 0x30e349b1, 0xc288cab2, 0xd1d83946, 0x23b3ba45, 0xf779deae,
    0x05125dad, 0x1642ae59, 0xe4292d5a, 0xba3a117e, 0x4851927d, 0x5b016189, 0xa96ae28a, 0x7da08661, 0x8fcb0562, 0x9c9bf696, 0x6ef07595, 0x417b1dbc, 0xb3109ebf, 0xa0406d4b,
    0x522bee48, 0x86e18aa3, 0x748a09a0, 0x67dafa54, 0x95b17957, 0xcba24573, 0x39c9c670, 0x2a993584, 0xd8f2b687, 0x0c38d26c, 0xfe53516f, 0xed03a29b, 0x1f682198, 0x5125dad3,
    0xa34e59d0, 0xb01eaa24, 0x42752927, 0x96bf4dcc, 0x64d4cecf, 0x77843d3b, 0x85efbe38, 0xdbfc821c, 0x2997011f, 0x3ac7f2eb, 0xc8ac71e8, 0x1c661503, 0xee0d9600, 0xfd5d65f4,
    0x0f36e6f7, 0x61c69362, 0x93ad1061, 0x80fde395, 0x72966096, 0xa65c047d, 0x5437877e, 0x4767748a, 0xb50cf789, 0xeb1fcbad, 0x197448ae, 0x0a24bb5a, 0xf84f3859, 0x2c855cb2,
    0xdeeedfb1, 0xcdbe2c45, 0x3fd5af46, 0x7198540d, 0x83f3d70e, 0x90a324fa, 0x62c8a7f9, 0xb602c312, 0x44694011, 0x5739b3e5, 0xa55230e6, 0xfb410cc2, 0x092a8fc1, 0x1a7a7c35,
    0xe811ff36, 0x3cdb9bdd, 0xceb018de, 0xdde0eb2a, 0x2f8b6829, 0x82f63b78, 0x709db87b, 0x63cd4b8f, 0x91a6c88c, 0x456cac67, 0xb7072f64, 0xa457dc90, 0x563c5f93, 0x082f63b7,
    0xfa44e0b4, 0xe9141340, 0x1b7f9043, 0xcfb5f4a8, 0x3dde77ab, 0x2e8e845f, 0xdce5075c, 0x92a8fc17, 0x60c37f14, 0x73938ce0, 0x81f80fe3, 0x55326b08, 0xa759e80b, 0xb4091bff,
    0x466298fc, 0x1871a4d8, 0xea1a27db, 0xf94ad42f, 0x0b21572c, 0xdfeb33c7, 0x2d80b0c4, 0x3ed04330, 0xccbbc033, 0xa24bb5a6, 0x502036a5, 0x4370c551, 0xb11b4652, 0x65d122b9,
    0x97baa1ba, 0x84ea524e, 0x7681d14d, 0x2892ed69, 0xdaf96e6a, 0xc9a99d9e, 0x3bc21e9d, 0xef087a76, 0x1d63f975, 0x0e330a81, 0xfc588982, 0xb21572c9, 0x407ef1ca, 0x532e023e,
    0xa145813d, 0x758fe5d6, 0x87e466d5, 0x94b49521, 0x66df1622, 0x38cc2a06, 0xcaa7a905, 0xd9f75af1, 0x2b9cd9f2, 0xff56bd19, 0x0d3d3e1a, 0x1e6dcdee, 0xec064eed, 0xc38d26c4,
    0x31e6a5c7, 0x22b65633, 0xd0ddd530, 0x0417b1db, 0xf67c32d8, 0xe52cc12c, 0x1747422f, 0x49547e0b, 0xbb3ffd08, 0xa86f0efc, 0x5a048dff, 0x8ecee914, 0x7ca56a17, 0x6ff599e3,
    0x9d9e1ae0, 0xd3d3e1ab, 0x21b862a8, 0x32e8915c, 0xc083125f, 0x144976b4, 0xe622f5b7, 0xf5720643, 0x07198540, 0x590ab964, 0xab613a67, 0xb831c993, 0x4a5a4a90, 0x9e902e7b,
    0x6cfbad78, 0x7fab5e8c, 0x8dc0dd8f, 0xe330a81a, 0x115b2b19, 0x020bd8ed, 0xf0605bee, 0x24aa3f05, 0xd6c1bc06, 0xc5914ff2, 0x37faccf1, 0x69e9f0d5, 0x9b8273d6, 0x88d28022,
    0x7ab90321, 0xae7367ca, 0x5c18e4c9, 0x4f48173d, 0xbd23943e, 0xf36e6f75, 0x0105ec76, 0x12551f82, 0xe03e9c81, 0x34f4f86a, 0xc69f7b69, 0xd5cf889d, 0x27a40b9e, 0x79b737ba,
    0x8bdcb4b9, 0x988c474d, 0x6ae7c44e, 0xbe2da0a5, 0x4c4623a6, 0x5f16d052, 0xad7d5351 };

#define CRC_ITER(i)                                                                                                                                                                \
    case i:                                                                                                                                                                        \
        crcA = _mm_crc32_u64(crcA, *(uint64_t*)(pA - 8 * (i)));                                                                                                                    \
        crcB = _mm_crc32_u64(crcB, *(uint64_t*)(pB - 8 * (i)));                                                                                                                    \
        crcC = _mm_crc32_u64(crcC, *(uint64_t*)(pC - 8 * (i)));

#define X0(n) CRC_ITER(n);
#define X1(n) X0(n + 1) X0(n)
#define X2(n) X1(n + 2) X1(n)
#define X3(n) X2(n + 4) X2(n)
#define X4(n) X3(n + 8) X3(n)
#define X5(n) X4(n + 16) X4(n)
#define X6(n) X5(n + 32) X5(n)
#define X7(n) X6(n + 64) X6(n)
#define CRC_ITERS_256_TO_2()                                                                                                                                                       \
    do                                                                                                                                                                             \
    {                                                                                                                                                                              \
        X0(256) X1(254) X2(250) X3(242) X4(226) X5(194) X6(130) X7(2)                                                                                                              \
    }                                                                                                                                                                              \
    while (0)

static constexpr uint32_t LEAF_SIZE_INTEL = 6 * 24;

__forceinline uint64_t _u64_clmul(uint64_t a, uint64_t b)
{
    uint64_t a0, a1, a2, a3;
    uint64_t b0, b1, b2, b3;
    uint64_t e0, e1, e2, e3;

    a0 = a & 0x1111111111111111ULL;
    a1 = a & 0x2222222222222222ULL;
    a2 = a & 0x4444444444444444ULL;
    a3 = a & 0x8888888888888888ULL;
    b0 = b & 0x1111111111111111ULL;
    b1 = b & 0x2222222222222222ULL;
    b2 = b & 0x4444444444444444ULL;
    b3 = b & 0x8888888888888888ULL;

    e0 = (a0 * b0) ^ (a1 * b3) ^ (a2 * b2) ^ (a3 * b1);
    e1 = (a0 * b1) ^ (a1 * b0) ^ (a2 * b3) ^ (a3 * b2);
    e2 = (a0 * b2) ^ (a1 * b1) ^ (a2 * b0) ^ (a3 * b3);
    e3 = (a0 * b3) ^ (a1 * b2) ^ (a2 * b1) ^ (a3 * b0);

    e0 &= 0x1111111111111111ULL;
    e1 &= 0x2222222222222222ULL;
    e2 &= 0x4444444444444444ULL;
    e3 &= 0x8888888888888888ULL;

    return e0 | e1 | e2 | e3;
}

typedef union __declspec(align(16)) m128i
{
    __int8 m128i_i8[16];
    __int16 m128i_i16[8];
    __int32 m128i_i32[4];
    __int64 m128i_i64[2];
    unsigned __int8 m128i_u8[16];
    unsigned __int16 m128i_u16[8];
    unsigned __int32 m128i_u32[4];
    unsigned __int64 m128i_u64[2];
} m128i;

__forceinline __m128i _si128_clmul_epi64(__m128i _a, __m128i _b, const int imm)
{
    auto a = *(m128i*)&_a;
    auto b = *(m128i*)&_b;
    m128i r {};
    r.m128i_u64[0] = _u64_clmul(a.m128i_u64[imm & 1], b.m128i_u64[(imm >> 4) & 1]);
    r.m128i_u64[1] = _byteswap_uint64(_u64_clmul(_byteswap_uint64(a.m128i_u64[imm & 1]), _byteswap_uint64(b.m128i_u64[(imm >> 4) & 1]))) >> 1;
    return *(__m128i*)&r;
}

auto HasHWCLMul = ([]()
{
    std::array<int, 4> cpui;
    __cpuid(cpui.data(), 1);
    return cpui[2] & 2;
})();

#ifdef __clang__
__attribute__((target("crc32,pclmul,sse4.1")))
#endif
uint32_t crc32(const void* M, uint32_t bytes, uint32_t prev /* = 0*/)
{
#ifdef __clang__
    if (std::__isa_available < 2)
#else
    if (!__check_isa_support(__IA_SUPPORT_SSE42))
#endif
    {
        const uint8_t* M8 = (const uint8_t*)M;
        uint32_t R = 0;
        for (uint32_t i = 0; i < bytes; ++i)
        {
            R = (R >> 8) ^ g_tbl[(R ^ M8[i]) & 0xFF];
        }
        return R;
    }
    uint64_t pA = (uint64_t)M;
    uint64_t crcA = prev;
    uint32_t toAlign = ((uint64_t)-(int64_t)pA) & 7;

    for (; toAlign && bytes; ++pA, --bytes, --toAlign)
        crcA = _mm_crc32_u8((uint32_t)crcA, *(uint8_t*)pA);

    while (bytes >= LEAF_SIZE_INTEL)
    {
        const uint32_t n = bytes < 256 * 24 ? bytes * 2731 >> 16 : 256;
        pA += 8 * n;
        uint64_t pB = pA + 8 * n;
        uint64_t pC = pB + 8 * n;
        uint64_t crcB = 0, crcC = 0;
        switch (n)
            CRC_ITERS_256_TO_2();

        crcA = _mm_crc32_u64(crcA, *(uint64_t*)(pA - 8));
        crcB = _mm_crc32_u64(crcB, *(uint64_t*)(pB - 8));
        const __m128i vK = _mm_cvtepu32_epi64(_mm_loadu_si128((__m128i*)(&g_lut_intel[n - 1])));
        const __m128i vA = HasHWCLMul ? _mm_clmulepi64_si128(_mm_cvtsi64_si128(crcA), vK, 0) : _si128_clmul_epi64(_mm_cvtsi64_si128(crcA), vK, 0);
        const __m128i vB = HasHWCLMul ? _mm_clmulepi64_si128(_mm_cvtsi64_si128(crcB), vK, 16) : _si128_clmul_epi64(_mm_cvtsi64_si128(crcB), vK, 16);
        crcA = _mm_crc32_u64(crcC, _mm_cvtsi128_si64(_mm_xor_si128(vA, vB)) ^ *(uint64_t*)(pC - 8));

        bytes -= 24 * n;
        pA = pC;
    }

    for (; bytes >= 8; bytes -= 8, pA += 8)
        crcA = _mm_crc32_u64(crcA, *(uint64_t*)(pA));

    for (; bytes; --bytes, ++pA)
        crcA = _mm_crc32_u8((uint32_t)crcA, *(uint8_t*)(pA));

    return (uint32_t)crcA;
}
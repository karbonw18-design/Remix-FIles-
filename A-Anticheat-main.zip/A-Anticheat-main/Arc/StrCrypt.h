#pragma once

#include "Utils.h"
#include <algorithm>
#include <array>
#include <stdint.h>
#include <stdio.h>
#include <string_view>
#include <type_traits>

#ifdef _MSC_VER
#define forceinline __forceinline
#define _noinline __declspec(noinline)
#else
#define forceinline inline __attribute__((always_inline))
#define _noinline __attribute__((noinline))
#endif

template <int32_t Length, typename T>
struct _ConstexprString
{
    T Chars[Length];

    constexpr _ConstexprString(const T (&InputStr)[Length])
    {
        std::copy_n(InputStr, Length, Chars);
    }

    constexpr operator const T*() const
    {
        return static_cast<const T*>(Chars);
    }
};

template <typename T>
constexpr T cryptLast(T c, int i)
{
    auto k1 = (0x83 - (((c ^ __TIME__[7]) & 0xdf) * 0x4c)) >> 1;
    auto k2 = (0x4b - ((0x6b & c) % 0xad)) & 0xcc;
    auto k3 = 0x67 - ((0xb3 & c) / 0x5b);
    auto k4 = ((~i & 0xac) ^ c) % 0xca;
    return (char)~(k3 + k4 - ~(k1 | k2));
};

template <typename T>
constexpr T cryptLast__alt(T c, int i)
{
    auto k1 = (0xca - (((c ^ __TIME__[7]) & 0xed) * 0x2b)) >> 1;
    auto k2 = (0x5e - ((0x5f & c) % 0x4b)) & 0xdb;
    auto k3 = 0x61 - ((0xdd & c) / 0x2b);
    auto k4 = ((~i & 0x3a) ^ c) % 0x4c;
    return (char)~(k3 + k4 - ~(k1 | k2));
};

template <_ConstexprString S, typename T, size_t Count, uint32_t InitialKey>
constexpr std::array<T, Count> _buildStaticStorage()
{
    std::array<T, Count> outStaticStorage;
    outStaticStorage[0] = (T)InitialKey;

    for (int i = 0; i < Count - 1; i++)
        outStaticStorage[i + 1] = S[i] ^ cryptLast(outStaticStorage[i], i);

    return outStaticStorage;
}

template <_ConstexprString S, typename T, size_t Count, uint32_t InitialKey>
constexpr std::array<T, Count> _buildStaticStorage_alt()
{
    std::array<T, Count> outStaticStorage;
    outStaticStorage[0] = (T)InitialKey;

    for (int i = 0; i < Count - 1; i++)
        outStaticStorage[i + 1] = S[i] ^ cryptLast__alt(outStaticStorage[i], i);

    return outStaticStorage;
}

template <typename T>
_noinline void __crypt(T* storage, const T* staticStorage, size_t Count)
{
    fuckIda;

    for (int i = 0; i < Count - 1; i++)
        storage[i] = staticStorage[i + 1] ^ cryptLast(staticStorage[i], i);
}

template <typename T>
forceinline void __crypt_forceinline(T* storage, const T* staticStorage, size_t Count)
{
    for (int i = 0; i < Count - 1; i++)
        storage[i] = staticStorage[i + 1] ^ cryptLast__alt(staticStorage[i], i);
}

template <typename T, size_t Count, uint32_t InitialKey, _ConstexprString S, bool bStatic>
class _crypt_str
{
public:
    T _storage[Count] = { 0 };
    constexpr static std::array<T, Count> _staticStorage = _buildStaticStorage<S, T, Count, InitialKey>();

    forceinline bool isCrypted()
    {
        return Count > 1 && _storage[0] == 0;
    }

    forceinline void crypt()
    {
        if (isCrypted())
        {
            if constexpr (bStatic)
            {
                constexpr std::array<T, Count> _nonStaticStorage = _buildStaticStorage_alt<S, T, Count, InitialKey>();
                __crypt_forceinline(_storage, _nonStaticStorage.data(), Count);
            }
            else
                __crypt(_storage, _staticStorage.data(), Count);
        }
    }

    forceinline void clear()
    {
        for (int i = 0; i < Count; i++)
            _storage[i] = 0;
    }

    forceinline T* get()
    {
        crypt();

        return (T*)_storage;
    }

    forceinline operator T*()
    {
        return get();
    }

    forceinline size_t len()
    {
        return Count - 1;
    }
};

#ifdef _DEBUG
#define _(ptr) ptr
#define _ns(ptr) ptr
#else
#define ___(x) x
#define __(x) ___(x)
#define _c_getCounter() __(__COUNTER__)
#define _InitialKey(f) cryptLast<uint32_t>(~((__LINE__ + __FILE__[0] + _c_getCounter() + __TIME__[7] + f) * 0x31), f)
#define crypt_str(ptr) _crypt_str<std::remove_const_t<std::remove_reference_t<decltype(*ptr)>>, sizeof(ptr) / sizeof(ptr[0]), _InitialKey(ptr[0]), ptr, false>()
#define crypt_str_ns(ptr) _crypt_str<std::remove_const_t<std::remove_reference_t<decltype(*ptr)>>, sizeof(ptr) / sizeof(ptr[0]), _InitialKey(ptr[0]), ptr, true>()
#define _(ptr) crypt_str(ptr).get()
#define _ns(ptr) crypt_str_ns(ptr).get()
#endif
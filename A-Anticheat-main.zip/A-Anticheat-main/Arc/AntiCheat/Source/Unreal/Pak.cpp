#include "pch.h"
#include "../../../Bootstrapper/Headers/Configuration.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include <atomic>
#include <chrono>
#include <ctype.h>
#include <tchar.h>
#include <thread>
#include <unordered_map>

UNPACK_MODULE(Pak);
PRESDK_MODULE(PakPatches);

int64 LastCall = 0;
int32 CallCount = 0;
void* HookAddress = nullptr;
bool bWhitelistOnly = false;

std::wstring PakDirectory;
bool (*MountOG)(__int64 a1, const wchar_t* InPakFilename, uint32 PakOrder, const wchar_t* InPath, bool bLoadIndex, void* OutPakListEntry);
bool Mount(__int64 a1, const wchar_t* InPakFilename, uint32 PakOrder, const wchar_t* InPath = NULL, bool bLoadIndex = true, void* OutPakListEntry = nullptr)
{
    fuckIda;
    if (!InPakFilename)
        return false;

    if (InPakFilename[1] == L':') // full path
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = SuspiciousPakLoad;
        DetectionInfo[_("ban")] = false;
        DetectionInfo[_("info")] = InPakFilename;

        SendDetectionReport(DetectionInfo);
        return false;
    }

    const wchar_t* slash = wcsrchr(InPakFilename, L'/');
    const wchar_t* back = wcsrchr(InPakFilename, L'\\');
    const wchar_t* base = slash && back ? (slash > back ? slash : back) + 1 : slash ? slash + 1 : back ? back + 1 : InPakFilename;

    std::wstring pakName(base);
    auto dot = pakName.rfind(_(L".pak"));
    if (dot != std::wstring::npos)
        pakName.erase(dot);
    else
        return false;

    std::filesystem::path pakPath = std::filesystem::path(PakDirectory) / base;

    auto SendFailure = [&]()
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = SuspiciousPakLoad;
        DetectionInfo[_("ban")] = false;
        DetectionInfo[_("info")] = base;

        SendDetectionReport(DetectionInfo);

        return false;
    };

    auto lastModified = std::filesystem::last_write_time(pakPath);

    bool bFound = false;
    //bool bWhitelisted = false;
    std::set<uint64_t> AllowedSizes;

    for (const auto& wp : WhitelistedPaks)
    {
        if (pakPath.stem().string() == wp.Name)
        {
            bFound = true;
            AllowedSizes.emplace(wp.Size);
            //if (std::filesystem::file_size(pakPath) != wp.Size)
            //    return SendFailure();

            //bWhitelisted = true;
            //break;
        }
    }

    if (bFound && !AllowedSizes.contains(std::filesystem::file_size(pakPath)))
        return SendFailure();

    bool bIsPakchunkEarly = false;
    if (!bFound)
    {
        if (bWhitelistOnly)
            return SendFailure();

        if (pakName.starts_with(_(L"z_")) || pakName.ends_with(_(L"_P")) || pakName.ends_with(_(L"_p")))
            return SendFailure();

        std::filesystem::path sigPath = pakPath;
        sigPath.replace_extension(_(L".sig"));

        if (std::filesystem::exists(sigPath) && std::filesystem::is_regular_file(sigPath))
        {
            auto lastModifiedSig = std::filesystem::last_write_time(sigPath);

            auto diff = lastModified - lastModifiedSig;

            if (diff > std::chrono::minutes(720))
                return SendFailure();
        }

        if (pakName.starts_with(_(L"pakchunk")))
        {
            auto dash = pakName.find(L'-');

            if (dash == std::wstring::npos)
                return SendFailure();

            auto pakChunkName = pakName.substr(8, dash - 8);

            bIsPakchunkEarly = pakChunkName == _(L"Early");
            if (pakChunkName.empty() || (!bIsPakchunkEarly && !iswdigit(pakChunkName[0])))
                return SendFailure();
        }
    }

    CallCount++;

    if (!bIsPakchunkEarly && CallCount > 3)
        LastCall = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

    return MountOG(a1, InPakFilename, PakOrder, InPath, bLoadIndex, OutPakListEntry);
}

void UnhookThr()
{
    fuckIda;
    while (true)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        auto now = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

        auto last = LastCall;
        auto diff = now - last;

        if (last > 0 && diff > 3000)
        {
            if (utocPatchAddr)
            {
                DWORD og;
                VirtualProtect(LPVOID(utocPatchAddr), 8, PAGE_EXECUTE_READWRITE, &og);
                memcpy(LPVOID(utocPatchAddr), utocPatchBytes, 8);
                VirtualProtect(LPVOID(utocPatchAddr), 8, og, &og);
            }

            if (pakPatchAddr)
            {
                DWORD og;
                VirtualProtect(LPVOID(pakPatchAddr), 6, PAGE_EXECUTE_READWRITE, &og);
                memcpy(LPVOID(pakPatchAddr), pakPatchBytes, 6);
                VirtualProtect(LPVOID(pakPatchAddr), 6, og, &og);
            }

            if (missingSignature)
            {
                DWORD og;
                VirtualProtect(LPVOID(missingSignature + 3), 4, PAGE_EXECUTE_READWRITE, &og);
                memcpy(LPVOID(missingSignature + 3), missingSignatureBytes, 4);
                VirtualProtect(LPVOID(missingSignature + 3), 4, og, &og);
            }

            if (HookAddress)
            {
                if (utocPatchAddr)
                {
                    DWORD og;
                    VirtualProtect(LPVOID(utocPatchAddr), 8, PAGE_EXECUTE_READWRITE, &og);
                    memcpy(LPVOID(utocPatchAddr), utocPatchBytes, 8);
                    VirtualProtect(LPVOID(utocPatchAddr), 8, og, &og);
                }

                if (pakPatchAddr)
                {
                    DWORD og;
                    VirtualProtect(LPVOID(pakPatchAddr), 6, PAGE_EXECUTE_READWRITE, &og);
                    memcpy(LPVOID(pakPatchAddr), pakPatchBytes, 6);
                    VirtualProtect(LPVOID(pakPatchAddr), 6, og, &og);
                }

                if (missingSignature)
                {
                    DWORD og;
                    VirtualProtect(LPVOID(missingSignature + 3), 4, PAGE_EXECUTE_READWRITE, &og);
                    memcpy(LPVOID(missingSignature + 3), missingSignatureBytes, 4);
                    VirtualProtect(LPVOID(missingSignature + 3), 4, og, &og);
                }

                UnHook(HookAddress);
                HookAddress = nullptr;
            }

            return;
        }
    }
}

void Properium()
{
    //MessageBoxA(nullptr, "transgender hook", "meow :3", MB_OK);
}

void Pak__UnpackInit()
{
    fuckIda;
#if WITH_SOCKET
    if (!ServerConfiguration.contains(_("modules")))
        return;

    const json& Modules = ServerConfiguration[_("modules")];
    if (!Modules.is_object())
        return;

    bool Checks = true;
    if (auto it = Modules.find(_("pak_checks")); it != Modules.end() && it->is_boolean())
        Checks = it->get<bool>();

    if (!Checks)
        return;

    if (auto it = Modules.find(_("pak_whitelist_only")); it != Modules.end() && it->is_boolean())
        bWhitelistOnly = it->get<bool>();
#endif
    auto sRef = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"_P.pak"));

    if (!sRef.Get())
        return;

    uint64_t MountAddrPart = 0;
    for (int i = 0; i < 2000; i++)
    {
        auto Ptr = (uint8_t*)(sRef.Get() - i);

        if (*Ptr == 0x48 && *(Ptr + 1) == 0x83 && *(Ptr + 2) == 0xEC)
        {
            MountAddrPart = uint64_t(Ptr);
            break;
        }
        else if (*Ptr == 0x48 && *(Ptr + 1) == 0x81 && *(Ptr + 2) == 0xEC)
        {
            MountAddrPart = uint64_t(Ptr);
            break;
        }
    }

    uint64_t MountAddr = 0;
    for (int i = 0; i < 2000; i++)
    {
        auto Ptr = (uint8_t*)(MountAddrPart - i);

        if (*Ptr == 0x48 && *(Ptr + 1) == 0x8B && *(Ptr + 2) == 0xC4)
        {
            MountAddr = uint64_t(Ptr);
            break;
        }
        else if (*Ptr == 0x48 && *(Ptr + 1) == 0x89 && *(Ptr + 2) == 0x5C)
        {
            MountAddr = uint64_t(Ptr);
            break;
        }
        else if (*Ptr == 0x4C && *(Ptr + 1) == 0x8B && *(Ptr + 2) == 0xDC)
        {
            MountAddr = uint64_t(Ptr);
            break;
        }
        else if (*Ptr == 0x40 && *(Ptr + 1) == 0x55)
        {
            MountAddr = uint64_t(Ptr);
            break;
        }
    }
    /*auto MountAddr = Memcury::Scanner::FindPattern(_("48 8B C4 44 89 40 ? 48 89 48 ? 55 53 41 54"));
    if (!MountAddr.IsValid())
        MountAddr = Memcury::Scanner::FindPattern(_("40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC
    ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 4C 8B E1 48 89 4C 24 ? 48 8B 49")); if (!MountAddr.IsValid())
        MountAddr = Memcury::Scanner::FindPattern(_("48 8B C4 44 89 40 ? 48 89 48 ? 55 53 41 57"));
    if (!MountAddr.IsValid())
        MountAddr = Memcury::Scanner::FindPattern(_("40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC
    ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 4C 8B F9 48 89 4D ? 48 8B 49 ? 33 DB")); if
    (!MountAddr.IsValid()) MountAddr = Memcury::Scanner::FindPattern(_("40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC
    24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 8A 9D")); if (!MountAddr.IsValid()) MountAddr
    = Memcury::Scanner::FindPattern(_("40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B
    05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 48 8B 85 ? ? ? ? 48 8B D9")); if (!MountAddr.IsValid()) MountAddr =
    Memcury::Scanner::FindPattern(_("48 8B C4 44 89 40 ? 48 89 48 ? 55 53 57"));*/

    PakDirectory = ProjectArc::Bootstrapper::GameFolder.substr(0, ProjectArc::Bootstrapper::GameFolder.rfind(_(L"\\Binaries\\Win64"))) + _(L"\\Content\\Paks");

    if (!std::filesystem::exists(PakDirectory) || !std::filesystem::is_directory(PakDirectory))
    {
        wipeFunction(Pak__TLSInit);
        return;
    }
#if WITH_SOCKET
    if (MountAddr)
    {
        HookAddress = (void*)MountAddr;
        Hook(MountAddr, Mount, MountOG);

        if (FortniteCL < 15685441)
            CreateThread(0, 0, LPTHREAD_START_ROUTINE(UnhookThr), 0, 0, 0);
    }
#endif
    //Hook(Memcury::Scanner::FindStringRef(L"STAT_FEngineLoop_Init").Get(), Properium);

    wipeFunction(Pak__TLSInit);
}

void PakPatches__PreSDKInit()
{
    fuckIda;
    if (!bIsFortnite || FortniteCL >= 14512399)
        return;
#if WITH_SOCKET
    if (!ServerConfiguration.contains(_("fortnite")))
        return;

    const json& Fortnite = ServerConfiguration[_("fortnite")];
    if (!Fortnite.is_object())
        return;
    bool CorruptData = false;
    if (auto it = Fortnite.find(_("patch_corrupt_data")); it != Fortnite.end() && it->is_boolean())
        CorruptData = it->get<bool>();

    if (!CorruptData)
        return;
#endif

    Memcury::Scanner UnsafeEnvironmentFinder = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"UnsafeEnvironment_Title"));

    Memcury::Scanner RequestExittFinder = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"Memory pools allocations failed, exiting...\n"));

    if (!UnsafeEnvironmentFinder.IsValid() || !RequestExittFinder.IsValid())
        return;

    uintptr_t UnsafeEnvironment_Title = 0;
    uintptr_t RequestExit = RequestExittFinder.ScanFor({ 0xE8 }, true, 1).RelativeOffset(1).Get();

    for (int i = 0; i < 2048; i++)
    {
        uint8_t* ptr = (uint8_t*)(UnsafeEnvironmentFinder.Get() - i);

        if (ptr[0] == 0x4C && ptr[1] == 0x8B && ptr[2] == 0xDC)
        {
            UnsafeEnvironment_Title = UnsafeEnvironmentFinder.Get() - i;
            break;
        }

        if (*(uint16_t*)(UnsafeEnvironmentFinder.Get() - i) == 0x5540)
        {
            UnsafeEnvironment_Title = UnsafeEnvironmentFinder.Get() - i;
            break;
        }
    }

    if (!UnsafeEnvironment_Title || !RequestExit)
        return;

    Patch<uint8_t>(UnsafeEnvironment_Title, 0xC3);
    Patch<uint8_t>(RequestExit, 0xC3);
}

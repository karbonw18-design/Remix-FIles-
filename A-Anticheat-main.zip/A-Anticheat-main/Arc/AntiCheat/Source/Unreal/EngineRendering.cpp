#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
ENGINE_MODULE(EngineRendering);

__forceinline void NullFunc(uint64_t FuncStart)
{
    //fuckIda;
    if (!FuncStart)
        return;

    uint64_t FuncEnd = FuncStart;
    while (true)
    {
        if (*(uint8_t*)FuncEnd == 0xC3)
            break;
        FuncEnd++;
    }
    if (FuncEnd == FuncStart)
        return;

    auto Size = FuncEnd - FuncStart;
    DWORD og;
    VirtualProtect(LPVOID(FuncStart), Size, PAGE_EXECUTE_READWRITE, &og);

    *(uint8*)FuncStart = 0xC3;
    for (int i = 1; i < Size; i += 2)
        *(uint16_t*)(FuncStart + i) = rand();

    VirtualProtect(LPVOID(FuncStart), Size, og, &og);
}

uint64_t DrawTransitionVft = 0;
uint64_t DrawTransitionAddress = 0;
void CheckForRenderHooks(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

    auto GameViewport = UEngine::GetEngine()->GameViewport;
    auto GameViewportVft = GameViewport->Vft;
    auto PostRenderVft = DrawTransitionVft - 1;
    auto PostRenderAddress = GameViewportVft[PostRenderVft];
    auto DrawTransitionVftOffset = DrawTransitionVft * 8;
    auto PostRenderJmp = Memcury::Scanner(PostRenderAddress).ScanFor({ 0x48, 0xFF, 0xA0 }, true, 0, 1, 0x100).Get();
    if (PostRenderJmp == uint64_t(PostRenderAddress))
        PostRenderJmp = __int64(PostRenderAddress) + 3;
    PostRenderJmp += 3;

    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;

    auto EndOfDT = Memcury::Scanner(DrawTransitionAddress).ScanFor({ 0xC3 }).Get() + 1;

    auto InitialDTHash = crc32((void*)DrawTransitionAddress, uint32_t(EndOfDT - DrawTransitionAddress), 0);
    auto InitialPRHash = crc32((void*)PostRenderAddress, uint32_t(PostRenderJmp + 4 - __int64(PostRenderAddress)), 0);
    auto PostRender__Bytes = *(uint64_t*)PostRenderAddress;
    while (true)
    {
        if (uint64_t(GameViewportVft[DrawTransitionVft]) < uint64_t(gameBase) || uint64_t(GameViewportVft[DrawTransitionVft]) >= uint64_t(gameBase) + gameSize
            || crc32((void*)DrawTransitionAddress, uint32_t(EndOfDT - DrawTransitionAddress), 0) != InitialDTHash || IsHooked((void*)DrawTransitionAddress)) [[unlikely]]
        {
            DetectionInfo[_("code")] = EngineRenderHooked;
            goto _end;
        }
        else if (uint64_t(GameViewportVft[PostRenderVft]) < uint64_t(gameBase) || uint64_t(GameViewportVft[PostRenderVft]) >= uint64_t(gameBase) + gameSize
            || crc32((void*)PostRenderAddress, uint32_t(PostRenderJmp + 4 - __int64(PostRenderAddress)), 0) != InitialPRHash || IsHooked((void*)PostRenderAddress))
            [[unlikely]]
        {
            DetectionInfo[_("code")] = EngineRenderHooked;
            goto _end;
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

void EngineRendering__EngineInit()
{
    fuckIda;

    auto DrawLineItem = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"STAT_Canvas_LineItemTime")).Get();

    if (DrawLineItem)
        for (int i = 0; i < 3000; i++)
        {
            if (*(uint8_t*)(DrawLineItem - i) == 0x48 && *(uint8_t*)(DrawLineItem - i + 1) == 0x8B && *(uint8_t*)(DrawLineItem - i + 2) == 0xC4)
            {
                DrawLineItem -= i;
                break;
            }
            if (*(uint8_t*)(DrawLineItem - i) == 0x4C && *(uint8_t*)(DrawLineItem - i + 1) == 0x8B && *(uint8_t*)(DrawLineItem - i + 2) == 0xDC)
            {
                DrawLineItem -= i;
                break;  
            }
        }
    NullFunc(DrawLineItem);

    auto DrawTextItem = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"STAT_Canvas_TextItemTime"));

    if (DrawTextItem.IsValid())
        for (int i = 0; i < 3000; i++)
        {
            if (*(uint8_t*)(DrawTextItem.Get() - i) == 0x48 && *(uint8_t*)(DrawTextItem.Get() - i + 1) == 0x81 && *(uint8_t*)(DrawTextItem.Get() - i + 2) == 0xEC)
            {
                DrawTextItem = Memcury::Scanner(DrawTextItem.Get() - i);
                break;
            }
            else if (*(uint8_t*)(DrawTextItem.Get() - i) == 0x48 && *(uint8_t*)(DrawTextItem.Get() - i + 1) == 0x83 && *(uint8_t*)(DrawTextItem.Get() - i + 2) == 0xEC)
            {
                DrawTextItem = Memcury::Scanner(DrawTextItem.Get() - i);
                break;
            }
        }

    if (DrawTextItem.IsValid())
        for (int i = 0; i < 3000; i++)
        {
            if (*(uint8_t*)(DrawTextItem.Get() - i) == 0x48 && *(uint8_t*)(DrawTextItem.Get() - i + 1) == 0x89 && *(uint8_t*)(DrawTextItem.Get() - i + 2) == 0x5C)
            {
                DrawTextItem = Memcury::Scanner(DrawTextItem.Get() - i);
                break;
            }
            else if (*(uint8_t*)(DrawTextItem.Get() - i) == 0x48 && *(uint8_t*)(DrawTextItem.Get() - i + 1) == 0x8B && *(uint8_t*)(DrawTextItem.Get() - i + 2) == 0xC4)
            {
                DrawTextItem = Memcury::Scanner(DrawTextItem.Get() - i);
                break;
            }
            else if (*(uint8_t*)(DrawTextItem.Get() - i) == 0x40 && *(uint8_t*)(DrawTextItem.Get() - i + 1) == 0x55)
            {
                DrawTextItem = Memcury::Scanner(DrawTextItem.Get() - i);
                break;
            }
        }
    NullFunc(DrawTextItem.Get());

    auto DrawBoxItem = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"STAT_Canvas_BoxItemTime")).Get();

    if (DrawBoxItem)
        for (int i = 0; i < 3000; i++)
        {
            if (*(uint8_t*)(DrawBoxItem - i) == 0x48 && *(uint8_t*)(DrawBoxItem - i + 1) == 0x8B && *(uint8_t*)(DrawBoxItem - i + 2) == 0xC4)
            {
                DrawBoxItem -= i;
                break;
            }
            if (*(uint8_t*)(DrawBoxItem - i) == 0x4C && *(uint8_t*)(DrawBoxItem - i + 1) == 0x8B && *(uint8_t*)(DrawBoxItem - i + 2) == 0xDC)
            {
                DrawBoxItem -= i;
                break;
            }
        }

    if (DrawBoxItem)
        NullFunc(DrawBoxItem);

    if (VersionInfo.FortniteVersion != 25.09)
    {
        auto GameViewport = UEngine::GetEngine()->GameViewport;
        auto bSuppressTransitionMessageOffset = GameViewport->GetOffset(_("GameInstance")) + sizeof(void*);

        for (uint64_t i = Offsets::ProcessEventVft; i < 0x100; i++)
        {
            auto funcBase = GameViewport->Vft[i];

            if (*(uint8*)(__int64(funcBase) + 2) == 0x01)
                continue;

            for (int x = 0; x < 0x40; x++)
            {
                if (*(uint8*)(__int64(funcBase) + x) == 0x80 && *(uint8*)(__int64(funcBase) + x + 1) == 0xb9
                        && *(uint32*)(__int64(funcBase) + x + 2) == bSuppressTransitionMessageOffset && *(uint8*)(__int64(funcBase) + x + 6) == 0x00
                    || *(uint8*)(__int64(funcBase) + x) == 0x38 && *(uint8*)(__int64(funcBase) + x + 1) == 0x8f
                        && *(uint32*)(__int64(funcBase) + x + 2) == bSuppressTransitionMessageOffset)
                {
                    DrawTransitionAddress = __int64(funcBase);
                    DrawTransitionVft = i;  
                    goto _ret;
                }
            }
        }
    }
_ret:

    if (DrawTransitionVft)
    {
        SpawnThread(CheckForRenderHooks, true, true);
    }

    wipeFunction(EngineRendering__EngineInit);
}

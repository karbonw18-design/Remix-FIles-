#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
ENGINE_MODULE(PlayerController);
using namespace ProjectArc::Bootstrapper;

uint64_t FindGetPlayerViewPointVft()
{
    uint64 ftspAddr = 0;

    auto ftspRef = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"%s failed to spawn a pawn"), true, 0, VersionInfo.EngineVersion >= 5.0).Get();

    if (!ftspRef)
        return 0;

    for (int i = 0; i < 1000; i++)
    {
        if (*(uint8_t*)(ftspRef - i) == 0x40 && *(uint8_t*)(ftspRef - i + 1) == 0x53)
        {
            ftspAddr = ftspRef - i;
            break;
        }
        else if (*(uint8_t*)(ftspRef - i) == 0x48 && *(uint8_t*)(ftspRef - i + 1) == 0x89 && *(uint8_t*)(ftspRef - i + 2) == 0x5C)
        {
            ftspAddr = ftspRef - i;
            break;
        }
    }

    if (!ftspAddr)
        return 0;

    auto PCVft = DefaultObjImpl(_("FortPlayerControllerAthena"))->Vft;
    int ftspIdx = 0;

    for (int i = 0; i < 0x1000; i++)
    {
        if (PCVft[i] == (void*)ftspAddr)
        {
            ftspIdx = i;
            break;
        }
    }

    if (ftspIdx == 0)
        return 0;

    if (bIsFortnite && VersionInfo.FortniteVersion >= 20 && *(uint8_t*)(PCVft[ftspIdx - 1]) == 0xE9)
        return Memcury::Scanner(PCVft[ftspIdx - 1]).RelativeOffset(1).Get();

    return __int64(ftspIdx - 1);
}

uint64_t GetPlayerViewPointVft = 0;
void CheckForPlayerControllerHooks(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;

    UGameInstance* GameInstance = nullptr;

    while (true)
    {
        if (!GameInstance)
        {
            if (!UWorld::GetWorld() || !UWorld::GetWorld()->OwningGameInstance)
            {
                Sleep(100);
                continue;
            }

            GameInstance = UWorld::GetWorld()->OwningGameInstance;
        }

        if (!GameInstance || IsBadReadPtr(GameInstance) || GameInstance->LocalPlayers.Num() <= 0)
        {
            Sleep(100);
            continue;
        }

        auto LocalPlayer = GameInstance->LocalPlayers[0];
        auto PlayerController = LocalPlayer->PlayerController;

        if (!PlayerController)
        {
            Sleep(100);
            continue;
        }
        auto PlayerControllerVft = PlayerController->Vft;

        if (GetPlayerViewPointVft)
        {
            auto GPVPAddr = PlayerControllerVft[GetPlayerViewPointVft];

            if (uint64_t(GPVPAddr) < uint64_t(gameBase) || uint64_t(GPVPAddr) >= uint64_t(gameBase) + gameSize || IsHooked(GPVPAddr)) [[unlikely]]
            {
                DetectionInfo[_("code")] = PlayerControllerHooked;
                goto _end;
            }
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

void PlayerController__EngineInit()
{
    fuckIda;
    if (bIsFortnite)
        GetPlayerViewPointVft = FindGetPlayerViewPointVft();

    SpawnThread(CheckForPlayerControllerHooks, true, false);

    wipeFunction(PlayerController__EngineInit);
}

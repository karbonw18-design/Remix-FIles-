#include "pch.h"
#include "../../../Bootstrapper/Headers/Configuration.h"
#include "../../Headers/Shared.h"
#include <chrono>
#include <thread>

UNPACK_MODULE(IoStore);

void IoStore__UnpackInit()
{
    fuckIda;
    if (!bIsFortnite || FortniteCL < 14512399)
    //if (!bIsFortnite || FortniteCL < 15685441)
        return;

#if WITH_SOCKET
    if (!ServerConfiguration.contains(_("fortnite")))
        return;

    const json& Fortnite = ServerConfiguration[_("fortnite")];
    if (!Fortnite.is_object())
        return;

    bool PatchIoStore = false;
    if (auto it = Fortnite.find(_("patch_iostore")); it != Fortnite.end() && it->is_boolean())
        PatchIoStore = it->get<bool>();

    if (!PatchIoStore)
        return;
#else
    if (FortniteCL < 15685441)
        return;
#endif

    utocPatchAddr = Memcury::Scanner::FindPattern(_("40 55 53 56 57 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 45 33 FF 49 8B F1")).Get();
    if (!utocPatchAddr)
        utocPatchAddr = Memcury::Scanner::FindPattern(
            _("40 55 53 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 48 8B 75 ? 45 33 ED 4C 8B 75"))
                            .Get();
    if (!utocPatchAddr)
        utocPatchAddr = Memcury::Scanner::FindPattern(_("40 55 53 56 57 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 4D 8B F1")).Get();


    if (utocPatchAddr)
    {
        memcpy(utocPatchBytes, LPVOID(utocPatchAddr), 8);
        Patch<uint32_t>(utocPatchAddr, 0x000001c7);
        Patch<uint32_t>(utocPatchAddr + 4, 0x90c30000);
    }

    pakPatchAddr = Memcury::Scanner::FindPattern(_("0F 84 ? ? ? ? 4C 8D ?? ? ? ? ? 41 8B 45")).Get();

    if (!pakPatchAddr)
        pakPatchAddr = Memcury::Scanner::FindPattern(_("0F 84 ? ? ? ? 4D 8D A5 ? ? ? ? 49 83 CF")).Get();

    if (pakPatchAddr)
    {
        memcpy(pakPatchBytes, LPVOID(pakPatchAddr), 6);
        Patch<uint32_t>(pakPatchAddr, 0x90909090);
        Patch<uint16_t>(pakPatchAddr + 4, 0x9090);
    }

    missingSignature = Memcury::Scanner::FindPattern(_("41 C7 ? ? ? ? ? 0F 10 05")).Get();
    if (missingSignature)
    {
        memcpy(missingSignatureBytes, LPVOID(missingSignature + 3), 4);
        Patch<uint32_t>(missingSignature + 3, 0x0);
    }
}
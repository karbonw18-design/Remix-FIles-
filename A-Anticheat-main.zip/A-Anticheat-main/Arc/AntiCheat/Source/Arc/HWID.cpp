#include "pch.h"
#include "../../../hmac_sha256.h"
#include "../../Headers/Shared.h"
#include <ncrypt.h>
#include <sddl.h>
#include <wincrypt.h>
#include <winioctl.h>
#include <windows.h>
#include <winternl.h>

typedef NTSTATUS(NTAPI* _NtFsControlFile)(HANDLE, HANDLE, PIO_APC_ROUTINE, PVOID, PIO_STATUS_BLOCK, ULONG, PVOID, ULONG, PVOID, ULONG);

__forceinline BOOL __stdcall __DeviceIoControl(
    HANDLE hDevice, DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesReturned, LPOVERLAPPED lpOverlapped)
{
    _NtFsControlFile NtFsControlFile = (_NtFsControlFile)LI_FN_NO_DEF(NtFsControlFile).get();

    NTSTATUS status;
    IO_STATUS_BLOCK localIoStatus = { 0 };
    PIO_STATUS_BLOCK pIoStatus = lpOverlapped ? (PIO_STATUS_BLOCK)lpOverlapped : &localIoStatus;

    if (lpOverlapped)
    {
        lpOverlapped->Internal = STATUS_PENDING;
        PVOID apcContext = ((ULONG_PTR)lpOverlapped->hEvent & 1) ? NULL : lpOverlapped;

        if (HIWORD(dwIoControlCode) == 9)
            status = NtFsControlFile(hDevice, lpOverlapped->hEvent, NULL, apcContext, pIoStatus, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize);
        else
            status
                = _li(NtDeviceIoControlFile)(hDevice, lpOverlapped->hEvent, NULL, apcContext, pIoStatus, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize);

        if (status == STATUS_PENDING)
            return FALSE;
        if (NT_SUCCESS(status))
        {
            if (lpBytesReturned)
                *lpBytesReturned = (DWORD)pIoStatus->Information;
            return TRUE;
        }

        return FALSE;
    }

    if (HIWORD(dwIoControlCode) == 9)
        status = NtFsControlFile(hDevice, NULL, NULL, NULL, pIoStatus, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize);
    else
        status = _li(NtDeviceIoControlFile)(hDevice, NULL, NULL, NULL, pIoStatus, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize);

    if (status == STATUS_PENDING)
    {
        status = _li(NtWaitForSingleObject)(hDevice, FALSE, NULL);

        if (NT_SUCCESS(status))
            status = pIoStatus->Status;
    }

    if (NT_SUCCESS(status))
    {
        if (lpBytesReturned)
            *lpBytesReturned = (DWORD)pIoStatus->Information;
        return TRUE;
    }

    return FALSE;
}


__forceinline std::string GetDiskSerialNumber(const std::string drivePath)
{
    HANDLE deviceHandle = CreateFileA(drivePath.c_str(), 0, 0, NULL, OPEN_EXISTING, NULL, NULL);
    if (deviceHandle == INVALID_HANDLE_VALUE)
    {
        return "";
    }

    STORAGE_PROPERTY_QUERY storagePropertyQuery;
    memset(&storagePropertyQuery, 0, sizeof(STORAGE_PROPERTY_QUERY));
    storagePropertyQuery.PropertyId = StorageDeviceProperty;
    storagePropertyQuery.QueryType = PropertyStandardQuery;

    STORAGE_DESCRIPTOR_HEADER storageDescriptorHeader = { 0 };
    DWORD dwBytesReturned = 0;
    if (!__DeviceIoControl(deviceHandle, IOCTL_STORAGE_QUERY_PROPERTY, &storagePropertyQuery, sizeof(STORAGE_PROPERTY_QUERY), &storageDescriptorHeader,
            sizeof(STORAGE_DESCRIPTOR_HEADER), &dwBytesReturned, NULL))
    {
        CloseHandle(deviceHandle);
        return "";
    }

    if (!storageDescriptorHeader.Size)
        return "";

    const DWORD outBufferSize = storageDescriptorHeader.Size;
    auto outBuffer = new BYTE[outBufferSize];

    memset(outBuffer, 0, outBufferSize);

    if (!__DeviceIoControl(deviceHandle, IOCTL_STORAGE_QUERY_PROPERTY, &storagePropertyQuery, sizeof(STORAGE_PROPERTY_QUERY), outBuffer, outBufferSize, &dwBytesReturned, NULL))
    {
        CloseHandle(deviceHandle);
        return "";
    }

    CloseHandle(deviceHandle);

    std::string serial;

    const STORAGE_DEVICE_DESCRIPTOR* pDeviceDescriptor = (STORAGE_DEVICE_DESCRIPTOR*)outBuffer;
    if (pDeviceDescriptor->SerialNumberOffset && *(outBuffer + pDeviceDescriptor->SerialNumberOffset))
        serial = std::string(reinterpret_cast<char*>(outBuffer + pDeviceDescriptor->SerialNumberOffset));

    return serial;
}

typedef NTSTATUS(NTAPI* T_NtQueryInformationToken)(
    HANDLE TokenHandle, TOKEN_INFORMATION_CLASS TokenInformationClass, PVOID TokenInformation, ULONG TokenInformationLength, PULONG ReturnLength);

__forceinline BOOL __GetTokenInformation(HANDLE TokenHandle, TOKEN_INFORMATION_CLASS TokenInformationClass, LPVOID TokenInformation, DWORD TokenInformationLength, PDWORD ReturnLength)
{
    auto __NtQueryInformationToken = (T_NtQueryInformationToken)LI_FN_NO_DEF(NtQueryInformationToken).cached();
    NTSTATUS status = __NtQueryInformationToken(TokenHandle, TokenInformationClass, TokenInformation, (ULONG)TokenInformationLength, (PULONG)ReturnLength);

    return NT_SUCCESS(status);
}

__forceinline std::string GetSID()
{
    HANDLE hToken;
    PTOKEN_USER pTokenUser = NULL;
    DWORD dwLength = 0;

    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
        return "";

    __GetTokenInformation(hToken, TokenUser, NULL, dwLength, &dwLength);
    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
    {
        CloseHandle(hToken);
        return "";
    }

    pTokenUser = (PTOKEN_USER)malloc(dwLength);
    if (!pTokenUser)
    {
        CloseHandle(hToken);
        return "";
    }

    if (!__GetTokenInformation(hToken, TokenUser, pTokenUser, dwLength, &dwLength))
    {
        free(pTokenUser);
        CloseHandle(hToken);
        return "";
    }

    UNICODE_STRING sid;
    if (RtlConvertSidToUnicodeString(&sid, pTokenUser->User.Sid, true) < 0)
    {
        free(pTokenUser);
        CloseHandle(hToken);
        return "";
    }

    std::string sidStr = "";

    for (int i = 0; i < sid.Length; i++)
        sidStr.push_back((char)sid.Buffer[i]);

    free(pTokenUser);
    CloseHandle(hToken);
    RtlFreeUnicodeString(&sid);

    return sidStr;
}

__forceinline std::string HashHWID(std::string s)
{
    BYTE hashBytes[32];

    hmac_sha256(_ns("WfjSzC4zkr3clUsh5ikqviCya9N7fSyf"), 32, s.c_str(), s.size(), hashBytes, 32);

    std::stringstream ss2;

    ss2 << std::hex;

    for (int i = 0; i < 32; i++)
        ss2 << std::setw(2) << std::setfill('0') << (int)hashBytes[i];

    return ss2.str();
}

struct RawSMBIOSData
{
    BYTE Used20CallingMethod;
    BYTE SMBIOSMajorVersion;
    BYTE SMBIOSMinorVersion;
    BYTE DmiRevision;
    DWORD Length;
    BYTE SMBIOSTableData[1];
};

enum class StructureType : BYTE
{
    SystemInformation = 0x01,
};

struct Header
{
    StructureType type;
    BYTE length;
    WORD handle;
};

struct SystemInformation : Header
{
    BYTE manufacturer;
    BYTE productName;
    BYTE version;
    BYTE serialNumber;
    BYTE uuid[16];
};

__forceinline UINT __GetSystemFirmwareTable(
    _In_ DWORD FirmwareTableProviderSignature, _In_ DWORD FirmwareTableID, _Out_writes_bytes_to_opt_(BufferSize, return) PVOID pFirmwareTableBuffer, _In_ DWORD BufferSize)
{
    auto Buffer = (DWORD*)malloc(BufferSize + 16);

    if (!Buffer)
        return 0;

    *Buffer = FirmwareTableProviderSignature;
    Buffer[2] = FirmwareTableID;
    Buffer[3] = BufferSize;
    Buffer[1] = 1;

    ULONG ReturnLength = 0;
    auto ReturnValue = _li(NtQuerySystemInformation)(SYSTEM_INFORMATION_CLASS(0x4C) /*_SYSTEM_FIRMWARE_TABLE_INFORMATION*/, Buffer, BufferSize + 16, &ReturnLength);

    if (ReturnValue >= 0 && pFirmwareTableBuffer)
    {
        memcpy(pFirmwareTableBuffer, Buffer + 4, (unsigned int)Buffer[3]);
        ReturnValue = 0;
    }

    free(Buffer);

    return Buffer[3];
}

__forceinline std::string GetSmUUID()
{
    BYTE constexpr Terminator[] = { 0x00, 0x00 };

    std::vector<BYTE> buffer(__GetSystemFirmwareTable('RSMB', 0, nullptr, 0));
    __GetSystemFirmwareTable('RSMB', 0, buffer.data(), static_cast<DWORD>(buffer.size()));

    const auto rawData = reinterpret_cast<RawSMBIOSData const*>(buffer.data());
    for (auto it = rawData->SMBIOSTableData, itEnd = it + rawData->Length; it < itEnd;)
    {
        switch (auto const header = reinterpret_cast<Header const*>(it); header->type)
        {
        default:
            it = std::search(it + header->length, itEnd, std::begin(Terminator), std::end(Terminator)) + sizeof(Terminator);
            continue;
        case StructureType::SystemInformation:
            if (header->length >= sizeof(SystemInformation))
            {
                auto const uuid = static_cast<SystemInformation const*>(header)->uuid;
                uint8_t const correctUuid[16] = { uuid[0x0], uuid[0x1], uuid[0x2], uuid[0x3], uuid[0x4], uuid[0x5], uuid[0x6], uuid[0x7], uuid[0x8], uuid[0x9], uuid[0xa],
                    uuid[0xb], uuid[0xc], uuid[0xD], uuid[0xE], uuid[0xF] };

                if (auto const begin = std::begin(correctUuid), end = std::end(correctUuid);
                    !std::all_of(begin, end, std::bind_front(std::equal_to(), 0x00)) && !std::all_of(begin, end, std::bind_front(std::equal_to(), 0xFF)))
                {
                    std::stringstream ss2;

                    ss2 << std::hex;

                    for (int i = 0; i < 16; i++)
                        ss2 << std::setw(2) << std::setfill('0') << (int)correctUuid[i];

                    return ss2.str();
                }
            }

            break;
        }

        break;
    }

    return "";
}

__forceinline std::vector<BYTE> GetEK()
{
    NCRYPT_PROV_HANDLE hProvider = NULL;
    if (_li(NCryptOpenStorageProvider)(&hProvider, _ns(L"Microsoft Platform Crypto Provider"), 0) != ERROR_SUCCESS)
        return {};

    DWORD cbResult = 0;
    if (_li(NCryptGetProperty)(hProvider, _ns(L"PCP_EKPUB"), nullptr, 0, &cbResult, 0) != ERROR_SUCCESS)
        return {};

    std::vector<BYTE> ekPub(cbResult);
    if (_li(NCryptGetProperty)(hProvider, _ns(L"PCP_EKPUB"), ekPub.data(), cbResult, &cbResult, 0) != ERROR_SUCCESS)
        return {};

    DWORD cbEncoded = 0;
    if (!_li(CryptEncodeObjectEx)(X509_ASN_ENCODING, CNG_RSA_PUBLIC_KEY_BLOB, ekPub.data(), 0, nullptr, nullptr, &cbEncoded))
        return {};

    std::vector<BYTE> encodedEk(cbEncoded);
    if (!_li(CryptEncodeObjectEx)(X509_ASN_ENCODING, CNG_RSA_PUBLIC_KEY_BLOB, ekPub.data(), 0, nullptr, encodedEk.data(), &cbEncoded))
        return {};

    return encodedEk;
}

__declspec(noinline) void* GetNVML()
{
    return LI_MODULE("nvml.dll").get();
}

__forceinline std::vector<std::string> GetGpuUUIDs()
{
    auto nvml = GetNVML();

    if (!nvml)
        return {};

    auto nvmlInit_ = LI_FN_NO_DEF(nvmlInit).in_cached(nvml);
    auto nvmlDeviceGetUUID_ = LI_FN_NO_DEF(nvmlDeviceGetUUID).in_cached(nvml);
    void *nvmlDeviceGetCount_, *nvmlDeviceGetHandleByIndex_;

    if (!nvmlInit_)
    {
        nvmlInit_ = LI_FN_NO_DEF(nvmlInit).in_cached(nvml);
        nvmlDeviceGetCount_ = LI_FN_NO_DEF(nvmlDeviceGetCount).in_cached(nvml);
        nvmlDeviceGetHandleByIndex_ = LI_FN_NO_DEF(nvmlDeviceGetHandleByIndex).in_cached(nvml);
    }
    else
    {
        nvmlDeviceGetCount_ = LI_FN_NO_DEF(nvmlDeviceGetCount_v2).in_cached(nvml);
        nvmlDeviceGetHandleByIndex_ = LI_FN_NO_DEF(nvmlDeviceGetHandleByIndex_v2).in_cached(nvml);
    }

    auto nvmlShutdown_ = LI_FN_NO_DEF(nvmlShutdown).in(nvml);

    if (!nvmlInit_ || !nvmlDeviceGetCount_ || !nvmlDeviceGetHandleByIndex_ || !nvmlDeviceGetUUID_ || !nvmlShutdown_)
        return {};

    auto nvmlInit = (int (*)())nvmlInit_;
    auto nvmlDeviceGetCount = (int (*)(uint32_t*))nvmlDeviceGetCount_;
    auto nvmlDeviceGetHandleByIndex = (int (*)(uint32_t, void**))nvmlDeviceGetHandleByIndex_;
    auto nvmlDeviceGetUUID = (int (*)(void*, char*, int))nvmlDeviceGetUUID_;
    auto nvmlShutdown = (int (*)())nvmlShutdown_;

    if (nvmlInit())
        return {};

    unsigned int device_count;
    if (nvmlDeviceGetCount(&device_count))
        return {};

    std::vector<std::string> GpuUUIDs;
    for (unsigned int i = 0; i < device_count; i++)
    {
        void* device;
        char uuid[96] = { 0 };

        if (nvmlDeviceGetHandleByIndex(i, &device))
            continue;

        if (nvmlDeviceGetUUID(device, uuid, 96))
            continue;

        GpuUUIDs.push_back(uuid);
    }

    nvmlShutdown();
    return GpuUUIDs;
}

__declspec(noinline) std::vector<std::string> GetHWIDs()
{
    GUARD_RET({});
    fuckIda;

    if (IsHooked(_li(NtDeviceIoControlFile)) || IsHooked(LI_FN_NO_DEF(NtFsControlFile).cached()) || IsHooked(_li(NtQuerySystemInformation)) || IsHooked(_li(NtQuerySystemInformation))
        || IsHooked(_li(RtlConvertSidToUnicodeString))
        || IsHooked(_li(NCryptGetProperty)))
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = HWIDHook;
        DetectionInfo[_("ban")] = true;

        SendDetectionReport(DetectionInfo);
        return {};
    }
    std::vector<std::string> HWIDs;

    HKEY hKey {};

    LONG openRes = _li(RegOpenKeyExA)(HKEY_LOCAL_MACHINE, _ns("SYSTEM\\CurrentControlSet\\Control\\SystemInformation"), 0, KEY_QUERY_VALUE, &hKey);

    if (!openRes)
    {
        char data[48] = {};
        LPCSTR value = _ns("ComputerHardwareId");
        DWORD outSize = 48;

        auto lStatus = _li(RegQueryValueExA)(hKey, value, 0, NULL, (LPBYTE)&data, &outSize);

        if (!lStatus)
        {
            if (outSize > 0)
            {
                data[std::clamp((int)outSize, 0, 47)] = 0;
                HWIDs.push_back(HashHWID(data));
            }
        }
    }

    _li(RegCloseKey)(hKey);

    openRes = _li(RegOpenKeyExA)(HKEY_LOCAL_MACHINE, _ns("SOFTWARE\\Microsoft\\SQMClient"), 0, KEY_QUERY_VALUE, &hKey);

    if (!openRes)
    {
        char data[48] = {};
        LPCSTR value = _ns("MachineId");
        DWORD outSize = 48;

        auto lStatus = _li(RegQueryValueExA)(hKey, value, 0, NULL, (LPBYTE)&data, &outSize);

        if (!lStatus)   
        {
            if (outSize > 0)
            {
                data[std::clamp((int)outSize, 0, 47)] = 0;
                HWIDs.push_back(HashHWID(data));
            }
        }
    }

    _li(RegCloseKey)(hKey);

    auto SID = GetSID();

    if (SID.size() > 0)
        HWIDs.push_back(HashHWID(SID));

    for (int i = 0; i < 15; i++)
    {
        auto diskSer = GetDiskSerialNumber(std::string(_ns("\\\\.\\PhysicalDrive")) + std::to_string(i));

        if (diskSer.size() > 0)
            HWIDs.push_back(HashHWID(diskSer));
    }

    auto SmUUID = GetSmUUID();

    if (SmUUID.size() > 0)
        HWIDs.push_back(HashHWID(SmUUID));

    auto EK = GetEK();

    if (EK.size() > 0)
    {
        std::stringstream ss2;

        ss2 << std::hex;

        for (int i = 0; i < EK.size(); i++)
            ss2 << std::setw(2) << std::setfill('0') << (int)EK[i];

        HWIDs.push_back(HashHWID(ss2.str()));
    }

    auto GpuUUIDs = GetGpuUUIDs();

    for (auto& GpuUUID : GpuUUIDs)
        if (GpuUUID.size() > 0)
            HWIDs.push_back(HashHWID(GpuUUID));

    return HWIDs;
}
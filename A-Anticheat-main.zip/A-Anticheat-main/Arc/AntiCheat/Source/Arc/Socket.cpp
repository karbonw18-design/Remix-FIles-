#include "pch.h"
#include "../../../hmac_sha256.h"
#include "../../Headers/Encryption.h"
#include "../../Headers/Shared.h"
#include <iomanip>
#include <winioctl.h>
using namespace ProjectArc::Encryption;
#include "../../../Bootstrapper/Headers/Configuration.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../../Tellurium/Headers/Options.h"
#include <thread>
#include <sddl.h>
#include <ncrypt.h>
#include <wincrypt.h>

extern std::vector<std::string> GetHWIDs();

__declspec(noinline) void InitHMAC()
{
    auto hmac = (uint8*)malloc(16);
    for (int i = 0; i < 16; i++)
        hmac[i] = rand() & 0xff;

    std::vector<unsigned char> c;
    c.reserve(16);

    for (int i = 0; i < 16; i++)
        c.push_back(hmac[i]);

    for (int i = 1; i < 16; i++)
    {
        c[i] ^= (0x67 & hmac[i - 1]) ^ 0x41;
    }

    _socket->sendBinary(c);

    signingKey = hmac;
}

__forceinline std::vector<unsigned char> HexToBytes(const std::string& hex)
{
    std::vector<unsigned char> bytes;

    for (unsigned int i = 0; i < hex.length(); i += 2)
    {
        std::string byteString = hex.substr(i, 2);
        unsigned char byte = (unsigned char)strtol(byteString.c_str(), NULL, 16);
        bytes.push_back(byte);
    }

    return bytes;
}

__declspec(noinline) std::string handleChallenge(std::string challenge)
{
    fuckIda;
    auto vec = HexToBytes(challenge);

    vec[0] ^= 0xaf;
    vec[0] &= 0xfa;
    vec[0] |= 0x9;
    // vec[0] = ~vec[0];
    vec[vec.size() - 1] &= 0xf5;
    vec[vec.size() - 1] ^= ~vec[0];
    for (int i = 1; i < vec.size() - 1; i++)
    {
        vec[i] ^= vec[i - 1];
        vec[i] ^= vec[i + 1];
        // vec[i] = ~vec[i] & vec[i - 1];
    }

    std::stringstream ss;
    ss << std::hex;

    for (int i = 0; i < vec.size(); i++)
        ss << std::setw(2) << std::setfill('0') << (int)vec[i];

    return ss.str();
}

/*__declspec(noinline) void Send(char* message)
{
    fuckIda;
    if (!_socket)
        return;

    uint8_t sig[32] = { 0 };
    if (signingKey) [[likely]]
    {
        //uint32 len;
        //HMAC(EVP_sha256(), (Encryption::signingKey), 16, (const uint8*)message, strlen(message), sig, &len);
        hmac_sha256(signingKey, 16, message, strlen(message), sig, 32);
    }

    _socket->sendBinary(EncryptMessage(message, sig));
    _socket->poll();
}


__declspec(noinline) void Send(std::string message)
{
    fuckIda;
    if (!_socket)
        return;

    uint8_t sig[32] = { 0 };
    if (signingKey) [[likely]]
    {
        //uint32 len;
        //HMAC(EVP_sha256(), (Encryption::signingKey), 16, (const uint8*)message.data(), message.size(), sig, &len);
        hmac_sha256(signingKey, 16, message.data(), message.size(), sig, 32);
    }

    _socket->sendBinary(EncryptMessage(message.data(), sig));
    _socket->poll();
}*/
__declspec(noinline) void Send(json& jsonMsg)
{
    GUARD;
    fuckIda;
    if (!_socket)
        return;

    jsonMsg[_("time")] = time(0);

    const std::string message = jsonMsg.dump();

    uint8_t sig[32] = { 0 };
    if (signingKey) [[likely]]
    {
        hmac_sha256(signingKey, 16, message.data(), message.size(), sig, 32);
    }

    _socket->sendBinary(EncryptMessage(message.data(), sig));
    _socket->poll();
}

void handleConfiguration(const json& config)
{
    GUARD;
    fuckIda;

    if (!config.is_object()) // this is stupid
        return;

    const auto tellIt = config.find(_("tellurium"));
    if (tellIt == config.end() || !tellIt->is_object())
        return;

    const auto backendIt = tellIt->find(_("backend"));
    if (backendIt == tellIt->end() || !backendIt->is_string())
        return;

    const std::string utf8 = backendIt->get<std::string>();
    const std::wstring wide = std::wstring(utf8.begin(), utf8.end());

    if (!wide.empty())
        Tellurium::Unreal::backend = Tellurium::Unreal::FString::ConstructMalloc(wide.c_str());

    if (const auto mapIt = tellIt->find(_("mapping")); mapIt != tellIt->end() && mapIt->is_boolean() && mapIt->get<bool>())
    {
        if (const auto hostsIt = tellIt->find(_("hosts")); hostsIt != tellIt->end() && hostsIt->is_object())
        {
            for (auto& [k, v] : hostsIt->items())
            {
                if (!v.is_string())
                    continue;

                std::string vs = v.get<std::string>();

                std::wstring wk(k.begin(), k.end());
                std::wstring wv(vs.begin(), vs.end());

                Tellurium::Unreal::hostMap.emplace_back(std::move(wk), std::move(wv));
            }
        }

        if (const auto pathsIt = tellIt->find(_("paths")); pathsIt != tellIt->end() && pathsIt->is_object())
        {
            for (auto& [k, v] : pathsIt->items())
            {
                if (!v.is_string())
                    continue;

                std::string vs = v.get<std::string>();

                std::wstring wk(k.begin(), k.end());
                std::wstring wv(vs.begin(), vs.end());

                Tellurium::Unreal::pathMap.emplace_back(std::move(wk), std::move(wv));
            }
        }
    }

    const auto paksIt = config.find(_("whitelisted_paks"));
    if (paksIt == config.end() || !paksIt->is_array())
        return;

    for (const auto& pak : *paksIt)
    {
        if (!pak.is_object())
            continue;

        const auto nameIt = pak.find(_("name"));
        const auto sizeIt = pak.find(_("size"));

        if (nameIt == pak.end() || !nameIt->is_string())
            continue;
        if (sizeIt == pak.end() || !sizeIt->is_number_unsigned())
            continue;

        WhitelistedPaks.push_back({ nameIt->get<std::string>(), sizeIt->get<uint64_t>() });
    }
}

void handleCommand(const json& command)
{
    GUARD;
    fuckIda;
    if (!command.is_object())
        return;

    const auto cmdIt = command.find(_("command"));
    if (cmdIt == command.end() || !cmdIt->is_string())
        return;

    const std::string cmd = cmdIt->get<std::string>();

    if (cmd == _("messagebox"))
    {
        const auto titleIt = command.find(_("title"));
        const auto messageIt = command.find(_("message"));
        const auto typeIt = command.find(_("type"));

        std::string title = _("Arc");
        std::string message = _("");
        UINT type = MB_OK;

        if (titleIt != command.end() && titleIt->is_string())
            title = titleIt->get<std::string>();

        if (messageIt != command.end() && messageIt->is_string())
            message = messageIt->get<std::string>();

        if (typeIt != command.end() && typeIt->is_string())
        {
            std::string typeStr = typeIt->get<std::string>();
            if (typeStr == _("error"))
                type = MB_ICONERROR | MB_OK;
            else if (typeStr == _("warning"))
                type = MB_ICONWARNING | MB_OK;
            else if (typeStr == _("info"))
                type = MB_ICONINFORMATION | MB_OK;
        }

        _li(MessageBoxA)(nullptr, message.c_str(), title.c_str(), type | MB_TOPMOST);
    }
	else if (cmd == _("crash"))
	{
		*(uint64_t*)_AddressOfReturnAddress() = 0;
		_li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
		//Erase();
		return;
	}
}

void MessageHandler(std::vector<uint8_t> encryptedData)
{
    GUARD;
    fuckIda;
    auto msg = DecryptMessage(encryptedData);

    uint8_t sig[32] = { 0 };
    // uint32 len;

    // HMAC(EVP_sha256(), (Encryption::signingKey), 16, (const uint8*)msg, strlen(msg), sig, &len);
    hmac_sha256(signingKey, 16, msg, strlen(msg), sig, 32);

    auto sig_ = encryptedData.data() + (encryptedData.size() - 32);
    if (memcmp(sig, sig_, 32))
    {
        *(uint64_t*)_AddressOfReturnAddress() = 0x0;
        //Erase();
        _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
        //_li(MessageBoxA)(nullptr, _("Failed to authenticate the server.\nPlease check your internet connection and try again."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return;
    }

    json data;

    try
    {
        data = json::parse(msg);
    }
    catch (const std::exception&)
    {
        //   MessageBoxA(nullptr, e.what(), "Arc", MB_OK | MB_ICONERROR | MB_TOPMOST);
        return;
    }
    catch (...)
    {
        // MessageBoxA(nullptr, "unk json err", "Arc", MB_OK | MB_ICONERROR | MB_TOPMOST);
        return;
    }

    delete[] msg;

    if (data.is_object())
    {
        if (data.contains(_("challenge")) && data[_("challenge")].is_string()) [[unlikely]]
        {
            const std::string challengeStr = data[_("challenge")].get<std::string>();
            const std::string challengeRes = handleChallenge(challengeStr);

            json j = json::object();
            j[_("type")] = _("challenge");
            j[_("res")] = challengeRes;
            j[_("version")] = Config.Version;

            Send(j);
            return;
        }
        else if (data.contains(_("type")))
        {
            const auto& typeVal = data[_("type")];

            if (typeVal.is_string())
            {
                const std::string type = typeVal.get<std::string>();

                if (type == _("challengeSuccess"))
                {
                    json j = json::object();
                    j[_("type")] = _("client_info");

                    json info = json::object();
                    //                    info[_("version")] = Config.Version;

                    j[_("info")] = info;

                    Send(j);
                }
                else if (type == _("challengeFailed"))
                {
                    //_li(MessageBoxA)(0, _("Failed to authenticate the server.\nPlease check your internet connection and try again."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
                    *(uint64_t*)_AddressOfReturnAddress() = 0x0;
                    _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
                    //Erase();
                    return;
                }
                else if (type == _("client_info"))
                {
                    if (data.contains(_("info")) && data[_("info")].is_object())
                    {
                        const auto& info = data[_("info")];

                        double ver = 0.0;
                        if (info.contains(_("version")) && info[_("version")].is_number())
                            ver = info[_("version")].get<double>();

                        if (ver < Config.Version - 0.1f || ver > Config.Version)
                        {
                            if (bReadyToLaunch)
                                Freeze();

                            _li(MessageBoxA)(
                                nullptr, _("This version of the Arc client is outdated.\n\nPlease update it in order to play."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);

                            if (bReadyToLaunch)
                                Unfreeze();

                            *(uint64_t*)_AddressOfReturnAddress() = 0x0;
                            return;
                        }

                        json j = json::object();
                        j[_("type")] = _("configuration");

                        Send(j);
                    }
                    else // if it fails we cant be so sure that the client is legit
                    {
                        *(uint64_t*)_AddressOfReturnAddress() = 0x0;
                        return;
                    }
                }
                else if (type == _("configuration"))
                {
                    if (data.contains(_("payload")) && data[_("payload")].is_object())
                    {
                        handleConfiguration(data[_("payload")]);
                        ServerConfiguration = data[_("payload")];

                        json j = json::object();
                        j[_("type")] = _("hwid");
                        j[_("hwids")] = GetHWIDs();
                        Send(j);
                    }
                }
                else if (type == _("ban"))
                {
                    // todo: trace
                }
                else if (type == _("unban"))
                {
                    // todo: remove traces
                }
                else if (type == _("ready"))
                    bReadyToLaunch = true;
                else if (type == _("command"))
                {
                    if (data.contains(_("payload")) && data[_("payload")].is_object())
                    {
						std::thread([data]()
                        {
                           handleCommand(data[_("payload")]);
					    }).detach();
                    }
                }
            }

            return;
        }
        else if (data.contains(_("ping"))) [[likely]]
        {
            json j = json::object();
            j[_("type")] = _("pong");
            Send(j);
            return;
        }
    }
}

void SocketThread(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //if (ThrLdr)
    //    *ThrLdr = 1;

    auto ntdll = GetModuleHandleA(_("C:\\Windows\\System32\\ntdll.dll"));
    auto kernel32 = GetModuleHandleA(_("C:\\Windows\\System32\\kernel32.dll"));
    auto kernelbase = GetModuleHandleA(_("C:\\Windows\\System32\\kernelbase.dll"));
    auto user32 = GetModuleHandleA(_("C:\\Windows\\System32\\user32.dll"));
    auto win32u = GetModuleHandleA(_("C:\\Windows\\System32\\win32u.dll"));

    auto dosHeader = (IMAGE_DOS_HEADER*)ntdll;
    auto peHeader = (IMAGE_NT_HEADERS*)(__int64(ntdll) + dosHeader->e_lfanew);
    auto ntdllSize = peHeader->OptionalHeader.SizeOfImage;

    dosHeader = (IMAGE_DOS_HEADER*)kernel32;
    peHeader = (IMAGE_NT_HEADERS*)(__int64(kernel32) + dosHeader->e_lfanew);
    auto kernel32Size = peHeader->OptionalHeader.SizeOfImage;

    dosHeader = (IMAGE_DOS_HEADER*)kernelbase;
    peHeader = (IMAGE_NT_HEADERS*)(__int64(kernelbase) + dosHeader->e_lfanew);
    auto kernelbaseSize = peHeader->OptionalHeader.SizeOfImage;

    dosHeader = (IMAGE_DOS_HEADER*)user32;
    peHeader = (IMAGE_NT_HEADERS*)(__int64(user32) + dosHeader->e_lfanew);
    auto user32Size = peHeader->OptionalHeader.SizeOfImage;

    dosHeader = (IMAGE_DOS_HEADER*)win32u;
    peHeader = (IMAGE_NT_HEADERS*)(__int64(win32u) + dosHeader->e_lfanew);
    auto win32uSize = peHeader->OptionalHeader.SizeOfImage;

    auto _NtResumeThread = (NTSTATUS (*)(HANDLE, PULONG))LI_FN_NO_DEF(NtResumeThread).cached();

    while (_socket->getReadyState() != easywsclient::WebSocket::CLOSED)
    {
        if (!bDeath)
        {
            for (auto& Thr : AntiCheatThreads)
            {
                auto Obj = _li(WaitForSingleObject)(Thr, 0);
                ULONG SuspendCount = 0;

                _NtResumeThread(Thr, &SuspendCount);
                while (SuspendCount > 1)
                    _NtResumeThread(Thr, &SuspendCount);

                if (Obj == 0 /* || suspendCnt != 0*/)
                {
                    uintptr_t startAddr = 0;
                    ULONG outLen;
                    _li(NtQueryInformationThread)(Thr, (THREADINFOCLASS)9, &startAddr, sizeof(uintptr_t), &outLen);

                    char s[1024];

                    sprintf_s(s, _("Thread start address: Arc.exe+%llx"), startAddr - __int64(__ThisBase));
                    json DetectionInfo;

                    DetectionInfo[_("type")] = _("detection");
                    DetectionInfo[_("code")] = ThreadDespawned;
                    DetectionInfo[_("ban")] = true;
                    DetectionInfo[_("info")] = s;
                    SendDetectionReport(DetectionInfo, false);

                    _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
                    *(uint64_t*)_AddressOfReturnAddress() = 0;
                    // Erase();
                    return;
                }
            }

            for (auto& Thr : VerifyCtxThreads)
            {
                CONTEXT Ctx;
                Ctx.ContextFlags = CONTEXT_CONTROL;
                GetThreadContext(Thr, &Ctx);

                // this looks so bad
                if ((Ctx.Rip < uint64_t(__ThisBase) || Ctx.Rip >= uint64_t(__ThisBase) + __ThisSize) &&
                    (Ctx.Rip < uint64_t(ntdll) || Ctx.Rip >= uint64_t(ntdll) + ntdllSize) &&
                    (Ctx.Rip < uint64_t(kernel32) || Ctx.Rip >= uint64_t(kernel32) + kernel32Size) &&
                    (Ctx.Rip < uint64_t(kernelbase) || Ctx.Rip >= uint64_t(kernelbase) + kernelbaseSize) &&
                    (Ctx.Rip < uint64_t(user32) || Ctx.Rip >= uint64_t(user32) + user32Size) &&
                    (Ctx.Rip < uint64_t(win32u) || Ctx.Rip >= uint64_t(win32u) + win32uSize) &&
                    (Ctx.Rip < uint64_t(gameBase) || Ctx.Rip >= uint64_t(gameBase) + gameSize))
                {

                    auto PEB = (li::detail::win::PEB_T*)__readgsqword(0x60);
                    auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
                    auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

                    wchar_t* Name = nullptr;
                    uint64_t Base = 0;
                    do
                    {
                        if ((const char*)Ctx.Rip >= Entry->DllBase && (const char*)Ctx.Rip <= Entry->DllBase + Entry->SizeOfImage) [[unlikely]]
                        {
                            Name = Entry->FullDllName.Buffer;
                            Base = uint64_t(Entry->DllBase);
                            break;
                        }
                    }
                    while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);

                    uintptr_t startAddr = 0;
                    ULONG outLen;
                    _li(NtQueryInformationThread)(Thr, (THREADINFOCLASS)9, &startAddr, sizeof(uintptr_t), &outLen);

                    char s[1024];

                    sprintf_s(s, _("Thread start address: Arc.exe+%llx\nThread RIP: %ls+%llx"), startAddr - __int64(__ThisBase), (Name ? Name : _(L"<unknown>")), uint64_t(Ctx.Rip) - Base);
                    json DetectionInfo;

                    DetectionInfo[_("type")] = _("detection");
                    DetectionInfo[_("code")] = ThreadTamperedWith;
                    DetectionInfo[_("ban")] = false;
                    DetectionInfo[_("info")] = s;
                    SendDetectionReport(DetectionInfo, false);

                    _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
                    *(uint64_t*)_AddressOfReturnAddress() = 0;
                    // Erase();
                    return;
                }
            }
        }

        _socket->poll();
        _socket->dispatchBinary(MessageHandler);
        Sleep(100);
    }

    if (!bReadyToLaunch)
    {
        if (SplashHWnd)
        {
            errorText = _(L"Server connection failed!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd, _("Server connection failed.\nPlease check your internet connection and try again."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
        *(uint64_t*)_AddressOfReturnAddress() = 0;
    }
    //Sleep(4500); // give server a small chance to restart
    InitSocket(true);
}

int numRetries = 0;
bool InitSocket(bool bReconnection)
{
    GUARD_RET(false);
    fuckIda;

    std::string cmd = GetCommandLineA();
    auto pos = cmd.find("-t=");
    if (pos != std::string::npos)
        ArcToken = cmd.substr(pos + 3);
    else
    {
        if (SplashHWnd)
        {
            errorText = _(L"Failed to find authentication token!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd,
            _("Failed to initialize!\n\nCould not find the authentication token!\nIf you are the developer, please "
              "check your launch code."),
            _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return false;
    }
    if (ArcToken[0] == '"')
        ArcToken = ArcToken.substr(1, ArcToken.find('"', 1) - 1);
    else
        ArcToken = ArcToken.substr(0, ArcToken.find(' '));

    std::string SocketURL = _("ws://dev-anticheat-socket-v1.arc-services.dev:2151/socket/v1/anticheat/?t=");
    SocketURL += ArcToken;
    _socket = easywsclient::WebSocket::from_url(SocketURL);

    if (!_socket && !bReconnection)
    {
        if (SplashHWnd)
        {
            errorText = _(L"Failed to connect to server!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd, _("Failed to connect to server.\nPlease check your internet connection and try again."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return false;
    }
    else if (!_socket && bReconnection)
    {
        if (++numRetries <= 3)
        {
            Sleep(5000);
            InitSocket(true);
        }
        else
        {
            Freeze();
            _li(MessageBoxA)(0, _("Connection to the server was lost.\nPlease check your internet connection and try again."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
            Unfreeze();
            // Erase();
            _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
            *(uint64_t*)_AddressOfReturnAddress() = 0;
            return false;
        }
    }
    numRetries = 0;

    InitHMAC();

    if (bReconnection)
        SocketThread(nullptr, nullptr);
    else
        SpawnThread(LPTHREAD_START_ROUTINE(SocketThread));

    return true;
}

#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
//INIT_MODULE(AntiDebug);

void AntiDebugThr()
{
    fuckIda;
    auto CurrentProcessHandle = _li(GetCurrentProcess)();
    auto NtQueryInformationProcess_ = _li(NtQueryInformationProcess);
    
    auto NtQueryInformationProcess__Bytes = *(uint64_t*)NtQueryInformationProcess_;
    while (true)
    {
        auto PEB = (PPEB)__readgsqword(0x60);
        unsigned char KernelDebugInfo = *(unsigned char*)0x7ffe02d4;
        DWORD dwProcessDebugFlags /*, dwProcessDebugPort*/, dwReturned;
        HANDLE hProcessDebugObject;

        NTSTATUS status;

        if (NtQueryInformationProcess__Bytes != *(uint64_t*)NtQueryInformationProcess_)
            goto _rep;
        //status = NtQueryInformationProcess_(CurrentProcessHandle, ProcessDebugPort, &dwProcessDebugPort, sizeof(DWORD), &dwReturned);

        status = NtQueryInformationProcess_(CurrentProcessHandle, (PROCESSINFOCLASS)0x1f, &dwProcessDebugFlags, sizeof(DWORD), &dwReturned);

        status = NtQueryInformationProcess_(CurrentProcessHandle, (PROCESSINFOCLASS)0x1e, &hProcessDebugObject, sizeof(HANDLE), &dwReturned);

        if (PEB->BeingDebugged /* || dwProcessDebugPort == -1*/ || dwProcessDebugFlags == 0 || hProcessDebugObject != 0 || (KernelDebugInfo & 0x01) || (KernelDebugInfo & 0x02))
        {
        _rep:
            // Freeze();

            /*json DetectionInfo;

            DetectionInfo[_("type")] = _("detection");
            DetectionInfo[_("code")] = DebuggerDetected;
            DetectionInfo[_("ban")] = true;
            SendDetectionReport(DetectionInfo, false);*/
            *(uint64_t*)_AddressOfReturnAddress() = 0;
            _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);

            return;
        }

        Sleep(100);
    }
}

void AntiDebug__Init()
{
    fuckIda;
    // CreateThread(0, 0, LPTHREAD_START_ROUTINE(AntiDebugThr), 0, 0, 0);
    SpawnThread(AntiDebugThr, true);

    wipeFunction(AntiDebug__Init);
}
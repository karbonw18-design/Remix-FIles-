#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include <d3d11.h>
#include <d3dcompiler.h>
#include <Psapi.h>
#pragma comment(lib, "d3dcompiler.lib")
INIT_MODULE(DirectX);

HRESULT(__stdcall* D3DCompileOG)(LPCVOID pSrcData, SIZE_T SrcDataSize, LPCSTR pSourceName, D3D_SHADER_MACRO* pDefines, ID3DInclude* pInclude, LPCSTR pEntrypoint, LPCSTR pTarget,
    UINT Flags1, UINT Flags2, ID3DBlob** ppCode, ID3DBlob** ppErrorMsgs);
HRESULT __stdcall D3DCompileHook(LPCVOID pSrcData, SIZE_T SrcDataSize, LPCSTR pSourceName, D3D_SHADER_MACRO* pDefines, ID3DInclude* pInclude, LPCSTR pEntrypoint, LPCSTR pTarget,
    UINT Flags1, UINT Flags2, ID3DBlob** ppCode, ID3DBlob** ppErrorMsgs)
{
    fuckIda;
    auto Ret = _ReturnAddress();

    auto vertexShader = crypt_str("cbuffer vertexBuffer : register(b0) \
            {\
              float4x4 ProjectionMatrix; \
            };\
            struct VS_INPUT\
            {\
              float2 pos : POSITION;\
              float4 col : COLOR0;\
              float2 uv  : TEXCOORD0;\
            };\
            \
            struct PS_INPUT\
            {\
              float4 pos : SV_POSITION;\
              float4 col : COLOR0;\
              float2 uv  : TEXCOORD0;\
            };\
            \
            PS_INPUT main(VS_INPUT input)\
            {\
              PS_INPUT output;\
              output.pos = mul( ProjectionMatrix, float4(input.pos.xy, 0.f, 1.f));\
              output.col = input.col;\
              output.uv  = input.uv;\
              return output;\
            }");
    auto pixelShader = crypt_str("struct PS_INPUT\
            {\
              float4 pos : SV_POSITION;\
              float4 col : COLOR0;\
              float2 uv  : TEXCOORD0;\
            };\
            SamplerState sampler0 : register(s0);\
            Texture2D texture0 : register(t0);\
            \
            float4 main(PS_INPUT input) : SV_Target\
            {\
              float4 out_col = input.col * texture0.Sample(sampler0, input.uv); \
              return out_col; \
            }");

    if (vertexShader.len() == SrcDataSize)
    {
        // almost confident, make sure just incase
        if (memcmp(pSrcData, vertexShader.get(), vertexShader.len() + 1) == 0)
        {
            json DetectionInfo;

            DetectionInfo[_("type")] = _("detection");
            DetectionInfo[_("code")] = ImGuiInitialization;
            DetectionInfo[_("ban")] = true;
            SendDetectionReport(DetectionInfo);
            return E_NOTIMPL;
        }
    }
    else if (pixelShader.len() == SrcDataSize)
    {
        // almost confident, make sure just incase
        if (memcmp(pSrcData, pixelShader.get(), pixelShader.len() + 1) == 0)
        {
            json DetectionInfo;

            DetectionInfo[_("type")] = _("detection");
            DetectionInfo[_("code")] = ImGuiInitialization;
            DetectionInfo[_("ban")] = true;
            SendDetectionReport(DetectionInfo);
            return E_NOTIMPL;
        }
    }

    return D3DCompileOG(pSrcData, SrcDataSize, pSourceName, pDefines, pInclude, pEntrypoint, pTarget, Flags1, Flags2, ppCode, ppErrorMsgs);
}

HRESULT (__stdcall* D3D11CreateDeviceAndSwapChainOG)(IDXGIAdapter* pAdapter, D3D_DRIVER_TYPE DriverType, HMODULE Software, UINT Flags, const D3D_FEATURE_LEVEL* pFeatureLevels,
    UINT FeatureLevels, UINT SDKVersion, const DXGI_SWAP_CHAIN_DESC* pSwapChainDesc, IDXGISwapChain** ppSwapChain, ID3D11Device** ppDevice, D3D_FEATURE_LEVEL* pFeatureLevel,
    ID3D11DeviceContext** ppImmediateContext);
HRESULT __stdcall D3D11CreateDeviceAndSwapChainHook(IDXGIAdapter* pAdapter, D3D_DRIVER_TYPE DriverType, HMODULE Software,
    UINT Flags, const D3D_FEATURE_LEVEL* pFeatureLevels,
    UINT FeatureLevels, UINT SDKVersion, const DXGI_SWAP_CHAIN_DESC* pSwapChainDesc, IDXGISwapChain** ppSwapChain, ID3D11Device** ppDevice, D3D_FEATURE_LEVEL* pFeatureLevel,
    ID3D11DeviceContext** ppImmediateContext)
{
    fuckIda;
    auto Ret = _ReturnAddress();

    if (uint64_t(Ret) < uint64_t(gameBase) + gameText->VirtualAddress || uint64_t(Ret) >= uint64_t(gameBase) + gameText->Misc.VirtualSize) [[unlikely]]
    {
        MODULEINFO modInfo;
        auto d3d = _li(GetModuleHandleA)(_("d3d11"));
        _li(K32GetModuleInformation)(_li(GetCurrentProcess)(), d3d, &modInfo, sizeof(MODULEINFO));

        if (uint64_t(Ret) < uint64_t(d3d) || uint64_t(Ret) >= uint64_t(d3d) + modInfo.SizeOfImage) [[unlikely]]
        {
            auto PEB = (li::detail::win::PEB_T*)__readgsqword(0x60);
            auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
            auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

            const wchar_t* DLLName = L"<unknown>";
            do
            {
                if (Ret >= Entry->DllBase && Ret <= Entry->DllBase + Entry->SizeOfImage)
                {
                    if (wcscmp(Entry->BaseDllName.Buffer, _(L"medal-hook64.dll")) == 0 || wcscmp(Entry->BaseDllName.Buffer, _(L"blitz_fortnite.dll")) == 0
                        || wcscmp(Entry->BaseDllName.Buffer, _(L"owe-client-x64.dll")) == 0) [[likely]]
                        goto _;

                    DLLName = Entry->BaseDllName.Buffer;
                }
            }
            while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);

            std::string u8DllName;
            std::wstring u16DllName = DLLName;
            std::transform(u16DllName.begin(), u16DllName.end(), std::back_inserter(u8DllName),
                [](wchar_t c)
                {
                    return (char)c;
                });

            json DetectionInfo;

            DetectionInfo[_("type")] = _("detection");
            DetectionInfo[_("code")] = ImGuiInitialization;
            DetectionInfo[_("ban")] = false;
            DetectionInfo[_("close")] = true;
            DetectionInfo[_("info")] = u8DllName;
            SendDetectionReport(DetectionInfo);
            return E_NOTIMPL;
        }
    }

_:
    return D3D11CreateDeviceAndSwapChainOG(
        pAdapter, DriverType, Software, Flags, pFeatureLevels, FeatureLevels, SDKVersion, pSwapChainDesc, ppSwapChain, ppDevice, pFeatureLevel, ppImmediateContext);
}

void DirectX__Init()
{
    fuckIda;
    Hook(_li(D3DCompile), D3DCompileHook, D3DCompileOG);
    Hook(_li(D3D11CreateDeviceAndSwapChain), D3D11CreateDeviceAndSwapChainHook, D3D11CreateDeviceAndSwapChainOG);

    wipeFunction(DirectX__Init);
}
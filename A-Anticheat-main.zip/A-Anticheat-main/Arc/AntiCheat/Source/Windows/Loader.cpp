#include "pch.h"
#include "../../Headers/Shared.h"
//INIT_MODULE(Loader);


int w_ends_with(const wchar_t* str, const wchar_t* suffix)
{
    size_t str_len = wcslen(str);
    size_t suffix_len = wcslen(suffix);

    return str_len >= suffix_len && !wcsncmp(str + str_len - suffix_len, suffix, suffix_len);
}


auto _LdrTlsIdx = _li(TlsAlloc)();
NTSTATUS(__stdcall* LdrLoadDllOG)(PWCHAR SearchPath_, PULONG LoadFlags, PUNICODE_STRING Name, PVOID* BaseAddress);
NTSTATUS __stdcall LdrLoadDllHook(PWCHAR SearchPath_, PULONG LoadFlags, PUNICODE_STRING Name, PVOID* BaseAddress)
{
    fuckIda;
    if (!Name || !Name->Buffer)
        return LdrLoadDllOG(SearchPath_, LoadFlags, Name, BaseAddress);

    if (_li(TlsGetValue)(_LdrTlsIdx))
        return LdrLoadDllOG(SearchPath_, LoadFlags, Name, BaseAddress);

    if (auto Handle = _li(GetModuleHandleW)(Name->Buffer))
        return LdrLoadDllOG(SearchPath_, LoadFlags, Name, BaseAddress);

    wchar_t fileName[2048] = { 0 };
    ULONG LongFlags = LoadFlags ? *LoadFlags : 0;
    ULONG NewFlags = LongFlags | 2;
    HMODULE lib = nullptr;

    auto _ret = LdrLoadDllOG(SearchPath_, &NewFlags, Name, (PVOID*)&lib);
        
    if (!lib) [[unlikely]]
    {
        *BaseAddress = nullptr;
        return _ret;
    }
    
    _li(GetModuleFileNameW)(lib, fileName, 2048);
    _li(FreeLibrary)(lib);

    if (fileName[0] == 0)
    {
        std::wstring s = _(L"Please DM this popup to ustruct on Discord!\n\nInfo: ");
        s += Name->Buffer;
        _li(MessageBoxW)(nullptr, s.c_str(), _(L"Arc"), MB_OK | MB_ICONERROR | MB_TOPMOST);
    }

    wchar_t lowered[2048];
    wcscpy_s(lowered, 2048, fileName);
    _wcslwr_s(lowered, 2048);

    //thread_local bool InVES = false;
    //TlsSetValue(_LdrTlsIdx, false);
#ifndef _DEBUG
    //auto dtc = crypt_str(L"c:\\windows\\system32\\driverstore\\filerepository");
#endif
    /*if (wcscmp(lowered, _(L"c:\\windows\\system32\\rsaenh.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\wintrust.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\wpnapps.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\crypt32.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\cryptnet.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\ntdll.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\rpcrt4.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\kernelbase.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\kernel32.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\shcore.dll")) == 0 ||
#ifndef _DEBUG
        //wcsncmp(lowered, dtc.get(), dtc.len()) == 0 ||
#endif
        wcscmp(lowered, _(L"c:\\windows\\system32\\kernel.appcore.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\cryptbase.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\user32.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\wldp.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\devobj.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\drvstore.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\gdi32.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\msasn1.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\shell32.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\winhttp.dll")) == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\uxtheme.dll")) == 0 || wcscmp(lowered, _(L"c:\\windows\\system32\\msctf.dll")) == 0 || fileName[0] == 0
        || wcscmp(lowered, _(L"c:\\windows\\system32\\bcryptprimitives.dll")) == 0) [[likely]]
        return LdrLoadDllOG(SearchPath_, LoadFlags, Name, BaseAddress);*/

    bool verified = true;
    if (wcscmp(fileName, _(L"C:\\Windows\\system32\\win64help.dll")) == 0) [[unlikely]]
        verified = false;

    if (verified)
    {
        _li(TlsSetValue)(_LdrTlsIdx, LPVOID(true));
        verified = VerifyEmbeddedSignature(fileName);
        _li(TlsSetValue)(_LdrTlsIdx, LPVOID(false));

        if (!verified) [[unlikely]]
        {
            if (!bIsFortnite || (!w_ends_with(Name->Buffer, _(L"GFSDK_Aftermath_Lib.x64.dll")) && !w_ends_with(Name->Buffer, _(L"libogg_64.dll"))))
            {
                char fileName8[2048];
                for (int i = 0; (i == 0 || fileName[i - 1]) && i < 2048; i++)
                    fileName8[i] = (char)fileName[i];

                json DetectionInfo;

                DetectionInfo[_("type")] = _("detection");
                DetectionInfo[_("code")] = UnsignedDLLLoaded;
                DetectionInfo[_("ban")] = false;
                DetectionInfo[_("info")] = std::string(_("File path: ")) + fileName8;

                SendDetectionReport(DetectionInfo);
            }

            *BaseAddress = nullptr;
        }
    }
    else
        *BaseAddress = nullptr;

    return verified ? LdrLoadDllOG(SearchPath_, LoadFlags, Name, BaseAddress) : STATUS_DLL_NOT_FOUND;
}

inline NTSTATUS(NTAPI* LdrLoadDll)(PWCHAR, ULONG, PUNICODE_STRING, PHANDLE);

void CheckForLoaderHooks(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

#ifdef _DEBUG
    auto LdrLoadDll_ = GetProcAddress(GetModuleHandleA("ntdll.dll"), "LdrLoadDll");
#else
    auto LdrLoadDll_ = _li(LdrLoadDll);
#endif
    auto LdrLoadDll__CachedBytes = *(uint32*)(__int64(LdrLoadDll_) + 1);
    auto WinTrust = _li(GetModuleHandleA)(_("wintrust.dll"));
    auto TextSect = GetSect(WinTrust, _(".text"));
    auto WTText = LPVOID(__int64(WinTrust) + TextSect->VirtualAddress);
    auto WTTextSize = TextSect->Misc.VirtualSize;
    auto InitialWTHash = crc32(WTText, WTTextSize, 0);

    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;
    while (true)
    {
        if (*(uint8*)LdrLoadDll_ != 0xe9 || *(uint32*)(__int64(LdrLoadDll_) + 1) != LdrLoadDll__CachedBytes)
        {
            DetectionInfo[_("code")] = FunctionUnhooked;
            goto _end;
        }
        else if (crc32(WTText, WTTextSize, 0) != InitialWTHash)
        {
            DetectionInfo[_("code")] = WinTrustPatched;
            DetectionInfo[_("ban")] = true;
            goto _end;
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

void Loader__Init()
{
    fuckIda;
#ifdef _DEBUG
    auto LdrLoadDll_ = GetProcAddress(GetModuleHandleA("ntdll.dll"), "LdrLoadDll");
#else
    auto LdrLoadDll_ = _li(LdrLoadDll);
#endif
    Hook(LdrLoadDll_, LdrLoadDllHook, LdrLoadDllOG);

    SpawnThread(CheckForLoaderHooks, true, true);

    wipeFunction(Loader__Init);
}

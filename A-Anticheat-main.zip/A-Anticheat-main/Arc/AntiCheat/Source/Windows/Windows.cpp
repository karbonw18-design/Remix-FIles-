#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
INIT_MODULE(Windows);
using namespace ProjectArc::Bootstrapper;

void(__stdcall* GetSystemTimeAsFileTimeOG)(void* OutTime);
void __stdcall GetSystemTimeAsFileTimeHook(void* OutTime)
{
    fuckIda;
    if (!IsAddrInLoadedModule(_ReturnAddress())) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ManualMappedDLL;
        DetectionInfo[_("ban")] = false;
        DetectionInfo[_("close")] = true;
        SendDetectionReport(DetectionInfo);
        return;
    }

    return GetSystemTimeAsFileTimeOG(OutTime);
}

BOOL __stdcall VirtualProtectHook(LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect)
{
    fuckIda;

    if ((lpAddress >= gameBase && uint64_t(lpAddress) < uint64_t(gameBase) + gameSize) || (lpAddress >= __ThisBase && uint64_t(lpAddress) < uint64_t(__ThisBase) + __ThisSize))
    {
        auto Ret = _ReturnAddress();
        if ((uint64_t(Ret) < uint64_t(gameBase) || uint64_t(Ret) >= uint64_t(gameBase) + gameSize)
            && (uint64_t(Ret) < uint64_t(__ThisBase) || uint64_t(Ret) >= uint64_t(__ThisBase) + __ThisSize)) [[unlikely]]
            return true; // lol
    }

    return VirtualProtectOG(lpAddress, dwSize, flNewProtect, lpflOldProtect);
}

NTSTATUS (*NtQueryVirtualMemoryOG)(
    HANDLE ProcessHandle, PVOID BaseAddress, uint32_t MemoryInformationClass, PVOID MemoryInformation, SIZE_T MemoryInformationLength, PSIZE_T ReturnLength);
NTSTATUS NtQueryVirtualMemoryHook(
    HANDLE ProcessHandle, PVOID BaseAddress, uint32_t MemoryInformationClass, PVOID MemoryInformation, SIZE_T MemoryInformationLength, PSIZE_T ReturnLength)
{
    fuckIda;

    if (ProcessHandle == (PVOID)-1 && BaseAddress == gameBase)
        return STATUS_ACCESS_VIOLATION;

    return NtQueryVirtualMemoryOG(ProcessHandle, BaseAddress, MemoryInformationClass, MemoryInformation, MemoryInformationLength, ReturnLength);
}

BOOLEAN(__cdecl * RtlAddFunctionTableOG)(PRUNTIME_FUNCTION FunctionTable, DWORD EntryCount, DWORD64 BaseAddress);
BOOLEAN __cdecl RtlAddFunctionTableHook(PRUNTIME_FUNCTION FunctionTable, DWORD EntryCount, DWORD64 BaseAddress)
{
    fuckIda;
    if (!IsAddrInLoadedModule(_ReturnAddress())) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ManualMappedDLL;
        DetectionInfo[_("ban")] = false;
        DetectionInfo[_("close")] = true;
        SendDetectionReport(DetectionInfo);
        return false;
    }

    return RtlAddFunctionTableOG(FunctionTable, EntryCount, BaseAddress);
}

void CheckForWindowsHooks(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

    auto GSTAFT = _li(GetSystemTimeAsFileTime);
    auto GSTAFT__CachedBytes = *(uint64*)(__int64(GSTAFT) + 1);

    auto RAFT = _li(RtlAddFunctionTable);
    auto RAFT__CachedBytes = *(uint64*)(__int64(RAFT) + 1);

    auto FIC = _li(FlushInstructionCache);
    auto FIC__CachedBytes = *(uint64*)(__int64(FIC) + 1);
    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;
    while (true)
    {
        if (*(uint8*)GSTAFT != 0xe9 || *(uint64*)(__int64(GSTAFT) + 1) != GSTAFT__CachedBytes)
        {
            DetectionInfo[_("code")] = FunctionUnhooked;
            goto _end;
        }
        else if (*(uint8*)RAFT != 0xe9 || *(uint64*)(__int64(RAFT) + 1) != RAFT__CachedBytes)
        {
            DetectionInfo[_("code")] = FunctionUnhooked;
            goto _end;
        }
        else if (*(uint8*)FIC != 0xe9 || *(uint64*)(__int64(FIC) + 1) != FIC__CachedBytes)
        {
            DetectionInfo[_("code")] = FunctionUnhooked;
            goto _end;
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

typedef struct _LARGE_STRING
{
    ULONG Length;
    ULONG MaximumLength : 31;
    ULONG bAnsi : 1;
    PVOID Buffer;
} LARGE_STRING, *PLARGE_STRING;


/*HWND(__stdcall* NtUserCreateWindowExOG)(DWORD dwExStyle, PLARGE_STRING plstrClassName, PLARGE_STRING plstrClsVersion, PLARGE_STRING plstrWindowName, DWORD dwStyle, int x,
    int y,
    int nWidth, int nHeight, HWND hWndParent, HMENU hMenu, HINSTANCE hInstance, LPVOID lpParam, DWORD dwFlags, PVOID acbiBuffer);
HWND __stdcall NtUserCreateWindowExHook(DWORD dwExStyle, PLARGE_STRING plstrClassName, PLARGE_STRING plstrClsVersion, PLARGE_STRING plstrWindowName, DWORD dwStyle, int x, int y,
    int nWidth, int nHeight, HWND hWndParent, HMENU hMenu, HINSTANCE hInstance, LPVOID lpParam, DWORD dwFlags, PVOID acbiBuffer)
{
    if (bEnableCWHook)
    {
        //UnHook(LI_FN_NO_DEF(NtUserCreateWindowEx).cached());
        bDisableSplashClose = true;
        PostMessageA(SplashHWnd, WM_CLOSE, 0, 0);
        //ShowWindow(SplashHWnd, SW_HIDE);

        bEnableCWHook = false;
        SplashHWnd = 0;
    }

    return NtUserCreateWindowExOG(
        dwExStyle, plstrClassName, plstrClsVersion, plstrWindowName, dwStyle, x, y, nWidth, nHeight, hWndParent, hMenu, hInstance, lpParam, dwFlags, acbiBuffer);
}*/

bool __stdcall FlushInstructionCacheHook(HANDLE hProcess, LPCVOID lpBaseAddress, SIZE_T dwSize)
{
    if (hProcess != (HANDLE)-1)
        return FlushInstructionCacheOG(hProcess, lpBaseAddress, dwSize);

    auto RetAddr = _ReturnAddress();
    if (uint64_t(RetAddr) >= uint64_t(__ThisBase) + thisText->VirtualAddress && uint64_t(RetAddr) <= uint64_t(__ThisBase) + thisText->Misc.VirtualSize) [[unlikely]]
        return FlushInstructionCacheOG(hProcess, lpBaseAddress, dwSize);

    if (IsHooked((void*)lpBaseAddress))
    {
        auto PEB = (li::detail::win::PEB_T*)__readgsqword(0x60);
        auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
        auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

        const wchar_t* DLLName = L"<unknown>";
        do
        {
            if (RetAddr >= Entry->DllBase && RetAddr <= Entry->DllBase + Entry->SizeOfImage)
            {
                if (wcscmp(Entry->BaseDllName.Buffer, _(L"DiscordHook64.dll")) == 0 || wcscmp(Entry->BaseDllName.Buffer, _(L"RTSSHooks64.dll")) == 0
                    || wcscmp(Entry->BaseDllName.Buffer, _(L"game_detour_64.dll")) == 0 || wcscmp(Entry->BaseDllName.Buffer, _(L"medal-hook64.dll")) == 0
                    || wcscmp(Entry->BaseDllName.Buffer, _(L"GameDetour64.dll")) == 0 || wcscmp(Entry->BaseDllName.Buffer, _(L"graphics-hook64.dll")) == 0
                    || wcscmp(Entry->BaseDllName.Buffer, _(L"gameoverlayrenderer64.dll")) == 0 || wcscmp(Entry->BaseDllName.Buffer, _(L"amdxc64.dll")) == 0
                    || wcscmp(Entry->BaseDllName.Buffer, _(L"amdihk64.dll")) == 0)
                    [[likely]]
                    goto _;

                DLLName = Entry->BaseDllName.Buffer;
                break;
            }
        }
        while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);

        std::string u8DllName;
        std::wstring u16DllName = DLLName;
        std::transform(u16DllName.begin(), u16DllName.end(), std::back_inserter(u8DllName),
            [](wchar_t c)
            {
                return (char)c;
            });

        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = DroppedHook;
        DetectionInfo[_("ban")] = false;
        DetectionInfo[_("close")] = true;
        DetectionInfo[_("info")] = "In DLL: " + u8DllName;
        SendDetectionReport(DetectionInfo);
        return false;
    }

_:
    return FlushInstructionCacheOG(hProcess, lpBaseAddress, dwSize);
}

void Windows__Init()
{
    fuckIda;
    Hook(_li(GetSystemTimeAsFileTime), GetSystemTimeAsFileTimeHook, GetSystemTimeAsFileTimeOG);
    Hook(_li(VirtualProtect), VirtualProtectHook, VirtualProtectOG);
    Hook(LI_FN_NO_DEF(NtQueryVirtualMemory).cached(), NtQueryVirtualMemoryHook, NtQueryVirtualMemoryOG);
    Hook(_li(RtlAddFunctionTable), RtlAddFunctionTableHook, RtlAddFunctionTableOG);
    //if (SplashHWnd)
    //    Hook(LI_FN_NO_DEF(NtUserCreateWindowEx).cached(), NtUserCreateWindowExHook, NtUserCreateWindowExOG);

    SpawnThread(CheckForWindowsHooks, true, true);

    wipeFunction(Windows__Init);
}

#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include <thread>
LATE_MODULE(BuildingOptions);

class ABuildingPlayerPrimitivePreview : public AActor
{
public:
    UCLASS_COMMON_MEMBERS(ABuildingPlayerPrimitivePreview);
};

class AFortPlayerControllerAthena : public AActor
{
public:
    UCLASS_COMMON_MEMBERS(AFortPlayerControllerAthena);

    DEFINE_PROP(TargetedBuilding, AActor*);
    DEFINE_PROP(bSupportQuickEdit, bool);
    DEFINE_PROP(bQuickEditEnabled, bool);
};

void (*CompleteBuildingEditInteraction)(void*);
inline void (*SelectResetOG)(void*) = nullptr;
inline void (*SelectEditOG)(void*) = nullptr;
inline void (*PerformBuildingEditInteractionOG)(void*) = nullptr;

void SelectEditHook(void* a1)
{
    SelectEditOG(a1);

    CompleteBuildingEditInteraction(a1);
}

void SelectResetHook(void* a1)
{
    SelectResetOG(a1);

    CompleteBuildingEditInteraction(a1);
}

void PerformBuildingEditInteractionHook(AFortPlayerControllerAthena* _this)
{
    if (_this && _this->TargetedBuilding && _this->TargetedBuilding->IsA<ABuildingPlayerPrimitivePreview>())
        return;

    return PerformBuildingEditInteractionOG(_this);
}

void BuildingOptions__LateInit()
{
    fuckIda;
    std::string sCmdLine(_li(GetCommandLineA)());
    auto EorPos = sCmdLine.find(_("-eor"));
    auto RorPos = sCmdLine.find(_("-ror"));
    auto DpePos = sCmdLine.find(_("-dpe"));
    auto QuickEditPos = sCmdLine.find(_("-simpleedit"));

    if ((VersionInfo.FortniteVersion < 24.30 && (EorPos != std::string::npos || RorPos != std::string::npos))
        || (VersionInfo.FortniteVersion < 15.20 && DpePos != std::string::npos))
    {
        auto EditModeInputComponent = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"EditModeInputComponent0"));

        if (EorPos != std::string::npos || RorPos != std::string::npos)
        {
            auto rdataSect = Memcury::PE::Section::GetSection(_(".rdata"));
            for (int i = 1; i < 0x5000; i++)
            {
                auto Addr = (uint8_t*)EditModeInputComponent.Get() + i;

                if (*Addr == 0x48 && *(Addr + 1) == 0x8D)
                {
                    auto Rel = Memcury::Scanner(Addr).RelativeOffset(3);

                    if (rdataSect.isInSection(Rel.Get()) && strcmp((char*)Rel.Get(), _("CompleteBuildingEditInteraction")) == 0)
                    {
                        CompleteBuildingEditInteraction = Memcury::Scanner(Addr).ScanFor({ 0x48, 0x8D }, false).RelativeOffset(3).GetAs<void(*)(void*)>();
                        break;
                    }
                }
            }
            //CompleteBuildingEditInteraction
            //    = Memcury::Scanner::FindStringRef<const char*>(_("CompleteBuildingEditInteraction")).ScanFor({ 0x48, 0x8D }, false).RelativeOffset(3).GetAs<void (*)(void*)>();

            auto SelectEditScanner = EditModeInputComponent;
            SelectEditScanner.ScanFor({ 0x48, 0x8D, 0x05 }, true, 1);

            if (RorPos != std::string::npos)
            {
                auto SelectResetScanner = SelectEditScanner;
                auto SelectReset = SelectResetScanner.ScanFor({ 0x48, 0x8D, 0x05 }, true).RelativeOffset(3).Get();

                Hook(SelectReset, SelectResetHook, SelectResetOG);
            }

            if (VersionInfo.FortniteVersion < 11 && EorPos != std::string::npos)
            {
                auto SelectEdit = SelectEditScanner.RelativeOffset(3).Get();

                Hook(SelectEdit, SelectEditHook, SelectEditOG);
            }
        }

        if (VersionInfo.FortniteVersion < 15.20 && DpePos != std::string::npos)
        {

            // auto PerformBuildingEditInteraction = Memcury::Scanner::FindStringRef<const
            // char*>(_("PerformBuildingEditInteraction")).ScanFor({ 0x48, 0x8D },
            // false).RelativeOffset(3).GetAs<void(*)(void*)>();

            // if (VersionInfo.FortniteVersion < 15.20)
            //     Hook(PerformBuildingEditInteraction, PerformBuildingEditInteractionHook,
            //     PerformBuildingEditInteractionOG);

            auto rdataSect = Memcury::PE::Section::GetSection(_(".rdata"));
            for (int i = 1; i < 0x5000; i++)
            {
                auto Addr = (uint8_t*)EditModeInputComponent.Get() - i;

                if (*Addr == 0x48 && *(Addr + 1) == 0x8D)
                {
                    auto Rel = Memcury::Scanner(Addr).RelativeOffset(3);

                    if (rdataSect.isInSection(Rel.Get()) && strcmp((char*)Rel.Get(), _("PerformBuildingEditInteraction")) == 0)
                    {
                        auto PerformBuildingEditInteraction = Memcury::Scanner(Addr).ScanFor({ 0x48, 0x8D }, false).RelativeOffset(3).Get();

                        Hook(PerformBuildingEditInteraction, PerformBuildingEditInteractionHook, PerformBuildingEditInteractionOG);
                        break;
                    }
                }
            }
        }
    }

    if (QuickEditPos != std::string::npos)
    {
    }

    wipeFunction(BuildingOptions__LateInit);
}
#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
LATE_MODULE(Arena);

struct FUIExtension final
{
public:
    uint8 Slot; // 0x0000(0x0001)(Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor,
                // HasGetValueTypeHash, NativeAccessSpecifierPublic)
    uint8 Pad_1[0x7]; // 0x0001(0x0007)(Fixing Size After Last Property [ Dumper-7 ])
    TSoftClassPtr<class UClass> WidgetClass; // 0x0008(0x0028)(Edit, DisableEditOnInstance, UObjectWrapper,
                                             // HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

struct EPlaylistUIExtensionSlot
{
public:
    UENUM_COMMON_MEMBERS(EPlaylistUIExtensionSlot);

    DEFINE_ENUM_PROP(Primary);
};

struct EUIExtensionSlot
{
public:
    UENUM_COMMON_MEMBERS(EUIExtensionSlot);

    DEFINE_ENUM_PROP(Primary);
};

class UFortPlaylistAthena : public UObject
{
public:
    UCLASS_COMMON_MEMBERS(UFortPlaylistAthena);

    DEFINE_PROP(UIExtensions, TArray<FUIExtension>);
    DEFINE_PROP(bAllowSquadFillOption, bool);
    DEFINE_PROP(EnforceSquadFill, bool);
    DEFINE_PROP(bShouldFillWhenNoSquadFillOption, bool);
    DEFINE_PROP(bEnforceFullSquadInUI, bool);
};

void Arena__LateInit()
{
    fuckIda;
    if (!bIsFortnite || VersionInfo.FortniteVersion < 10 || !ServerConfiguration.contains(_("fortnite")))
        return;

    const json& Fortnite = ServerConfiguration[_("fortnite")];
    if (!Fortnite.is_object())
        return;

    bool EnableArenaUI = false;
    if (auto it = Fortnite.find(_("enable_arena_ui")); it != Fortnite.end() && it->is_boolean())
        EnableArenaUI = it->get<bool>();

    if (!EnableArenaUI)
        return;

    TArray<FUIExtension> ArenaExtensions, ShowdownExtensions;

    auto PrimarySlot = uint8_t(EPlaylistUIExtensionSlot::StaticEnum() ? EPlaylistUIExtensionSlot::GetPrimary() : EUIExtensionSlot::GetPrimary());

    FUIExtension ArenaUIExtension {};
    ArenaUIExtension.Slot = PrimarySlot;
    if (VersionInfo.FortniteVersion < 23)
        ArenaUIExtension.WidgetClass.ObjectID.AssetPathName = FName(_(L"/Game/UI/Competitive/Arena/ArenaScoringHUD.ArenaScoringHUD_C"));
    else
    {
        auto& PackageName = *(FName*)(__int64(&ArenaUIExtension.WidgetClass) + (VersionInfo.EngineVersion < 5.3 ? 0xC : 0x8));
        auto& AssetName = *(FName*)(__int64(&ArenaUIExtension.WidgetClass) + (VersionInfo.EngineVersion < 5.3 ? 0x10 : 0xC));
        auto& SubPathString = *(SDKFString*)(__int64(&ArenaUIExtension.WidgetClass) + (VersionInfo.EngineVersion < 5.3 ? 0x14 : 0x10));

        PackageName = FName(_(L"/Game/UI/Competitive/Arena/ArenaScoringHUD"));
        AssetName = FName(_(L"ArenaScoringHUD_C"));
        SubPathString = SDKFString();
    }

    FUIExtension ShowdownUIExtension {};
    ShowdownUIExtension.Slot = PrimarySlot;
    if (VersionInfo.FortniteVersion < 23)
        ShowdownUIExtension.WidgetClass.ObjectID.AssetPathName = FName(_(L"/Game/UI/Frontend/Showdown/ShowdownScoringHUD.ShowdownScoringHUD_C"));
    else
    {
        auto& PackageName = *(FName*)(__int64(&ShowdownUIExtension.WidgetClass) + (VersionInfo.EngineVersion < 5.3 ? 0xC : 0x8));
        auto& AssetName = *(FName*)(__int64(&ShowdownUIExtension.WidgetClass) + (VersionInfo.EngineVersion < 5.3 ? 0x10 : 0xC));
        auto& SubPathString = *(SDKFString*)(__int64(&ShowdownUIExtension.WidgetClass) + (VersionInfo.EngineVersion < 5.3 ? 0x14 : 0x10));

        PackageName = FName(_(L"/Game/UI/Frontend/Showdown/ShowdownScoringHUD"));
        AssetName = FName(_(L"ShowdownScoringHUD_C"));
        SubPathString = SDKFString();
    }

    ArenaExtensions.Add(ArenaUIExtension);
    ShowdownExtensions.Add(ShowdownUIExtension);

    auto PlaylistClass = FindClass(_("FortPlaylistAthena"));

    for (int i = 0; i < TUObjectArray::Num(); i++)
    {
        auto Object = TUObjectArray::GetObjectByIndex(i);
        if (Object && Object->IsA((UClass*)PlaylistClass))
        {
            auto Playlist = (UFortPlaylistAthena*)Object;

            auto Name = Object->Name.ToString();
            if (Name.contains(_("Showdown")))
            {
                auto bShowdownAlt = Name.contains(_("ShowdownAlt"));
                if (bShowdownAlt)
                {
                    Playlist->bAllowSquadFillOption = true;
                    Playlist->EnforceSquadFill = false;
                    if (Playlist->HasbShouldFillWhenNoSquadFillOption())
                        Playlist->bShouldFillWhenNoSquadFillOption = false;
                    Playlist->bEnforceFullSquadInUI = false;
                }

                Playlist->UIExtensions = bShowdownAlt ? ArenaExtensions : ShowdownExtensions;
            }
        }
    }

    wipeFunction(Arena__LateInit);
}
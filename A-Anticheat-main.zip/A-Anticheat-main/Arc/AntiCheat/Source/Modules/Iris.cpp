#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
INIT_MODULE(Iris);

void Iris__Init()
{
    fuckIda;
    if (!bIsFortnite || FortniteCL < 27233190)
        return;

#if WITH_SOCKET
	if (!ServerConfiguration.contains(_("fortnite")))
		return;
	const json& Fortnite = ServerConfiguration[_("fortnite")];
	if (!Fortnite.is_object())
		return;
	bool EnableIris = false;
	if (auto it = Fortnite.find(_("force_iris")); it != Fortnite.end() && it->is_boolean())
		EnableIris = it->get<bool>();
	if (!EnableIris)
		return;
#endif

    auto IrisBool = FindCVar<uint32_t>(_(L"net.Iris.UseIrisReplication"));

    if (IrisBool)
        *IrisBool = true;

	if (IrisBool)
	{
		Memcury::PE::Address add{ nullptr };

        auto text = GetSect(gameBase, _(".text"));

        auto scanBytes = (uint8_t*)(__int64(gameBase) + text->VirtualAddress);
        auto sizeOfImage = text->Misc.VirtualSize;

		for (auto i = 0ul; i < sizeOfImage - 5; ++i)
		{
			if (scanBytes[i] == 0x83 || scanBytes[i] == 0x39)
			{
				if (Memcury::PE::Address(&scanBytes[i]).RelativeOffset(2, scanBytes[i] == 0x83).GetAs<void*>() == (void*)IrisBool)
				{
					add = Memcury::PE::Address(&scanBytes[i]);

					Patch<uint32_t>(__int64(&scanBytes[i]) + 2, 0x0); // the next bytes will always be greater than 0
				}
			}
		}
	}
}
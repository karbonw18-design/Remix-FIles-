#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <DbgHelp.h>
#include <TlHelp32.h>
#include <winternl.h>
#include "SDK/Includes.h"
#include "MinHook.h"
#include "LazyImporter.h"
#include "StrCrypt.h"
#include "json.hpp"
#include "easywsclient.hpp"
#include <SoftPub.h>
#include <WinTrust.h>
#include <mscat.h>
#pragma comment(lib, "wintrust.lib")
using namespace SDK;

#pragma comment(lib, "dbghelp.lib")
#pragma comment(lib, "ntdll.lib")
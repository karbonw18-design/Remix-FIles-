#include "pch.h"
#include "../Headers/Unreal.h"
#include "../../AntiCheat/Headers/Shared.h"
#include "../../Bootstrapper/Headers/Configuration.h"
#include "../Headers/Options.h"
#include "../Headers/Redirection.h"
#include <minwinbase.h>
#include <thread>

namespace Tellurium
{
    namespace Unreal
    {
        FString::FString()
        {
            String = nullptr;
            Length = MaxSize = 0;
        }

        FString::FString(const char* Other)
        {
            if (Other)
            {
                MaxSize = Length = (int)strlen(Other) + 1;

                AllocString();

                size_t ConvertedChars = 0;
                mbstowcs_s(&ConvertedChars, String, Length, Other, _TRUNCATE);
            }
        }

        FString::FString(wchar_t* Other)
        {
            if (Other)
            {
                MaxSize = Length = (int)wcslen(Other) + 1;

                AllocString();

                __movsb((PBYTE)String, (const PBYTE)Other, Length * sizeof(wchar_t));
            }
        }

        FString::FString(uint32_t len)
        {
            MaxSize = Length = len + 1;
            AllocString();
        }

        __declspec(noinline) FString FString::operator+(FString other)
        {
            if (!String || !other.String)
                return *this;
            auto sLen = Length - 1;
            auto oLen = other.Length - 1;

            FString nStr((uint32_t)(sLen + oLen));
            __movsb((PBYTE)nStr.String, (const PBYTE)String, sLen * sizeof(wchar_t));
            __movsb((PBYTE)nStr.String + sLen * sizeof(wchar_t), (const PBYTE)other.String, oLen * sizeof(wchar_t));
            nStr.String[nStr.Length - 1] = 0;

            return nStr;
        }

        __declspec(noinline) void FString::operator+=(FString other)
        {
            if (!String || !other.String)
                return;
            auto sLen = Length - 1;
            auto oLen = other.Length - 1;
            Length = (uint32_t)(sLen + oLen + 1);
            auto os = String;

            AllocString();
            __movsb((PBYTE)String, (const PBYTE)os, sLen * sizeof(wchar_t));
            __movsb((PBYTE)String + sLen * sizeof(wchar_t), (const PBYTE)other.String, oLen * sizeof(wchar_t));
            String[Length - 1] = 0;
            free(os);
        }

        __declspec(noinline) FString FString::substr(size_t off, size_t count)
        {
            if (count == -1)
                count = Length - off - 1;
            else if (count > Length)
                return *this;
            FString nStr((uint32_t)count);

            __movsb((PBYTE)nStr.String, (const PBYTE)(String + off), count * sizeof(wchar_t));
            nStr.String[count] = 0;

            return nStr;
        }

        __declspec(noinline) size_t FString::find(wchar_t c)
        {
            for (uint32_t i = 0; i < Length; i++)
                if (String[i] == c)
                    return i;

            return -1;
        }

        size_t FString::find(char c)
        {
            return find((wchar_t)c);
        }

        size_t FString::find(const wchar_t* c)
        {
            for (uint32_t i = 0; i < Length; i++)
            {
                bool found = true;
                for (int x = 0; x < wcslen(c); x++)
                {
                    if (String[i + x] != c[x])
                    {
                        found = false;
                        break;
                    }
                }

                if (found)
                    return i;
            }

            return -1;
        }

        bool FString::contains(wchar_t c)
        {
            for (uint32_t i = 0; i < Length; i++)
                if (String[i] == c)
                    return true;

            return false;
        }

        bool FString::contains(const wchar_t* c)
        {
            for (uint32_t i = 0; i < Length; i++)
            {
                bool found = true;
                for (int x = 0; x < wcslen(c); x++)
                {
                    if (String[i + x] != c[x])
                    {
                        found = false;
                        break;
                    }
                }

                if (found)
                    return true;
            }
            return false;
        }

        bool FString::starts_with(const wchar_t* c)
        {
            for (int x = 0; x < wcslen(c); x++)
                if (String[x] != c[x])
                    return false;

            return true;
        }

        bool FString::ends_with(const wchar_t* c)
        {
            auto cLen = wcslen(c);
            auto start = ((size_t)Length - 1) - cLen;

            for (size_t x = 0; x < cLen; x++)
                if (String[start + x] != c[x])
                    return false;

            return true;
        }

        size_t FString::find_first_of(char c)
        {
            return find(c);
        }

        size_t FString::find_first_of(wchar_t c)
        {
            return find(c);
        }

        wchar_t* FString::c_str()
        {
            return String;
        }

        FString::operator wchar_t*()
        {
            return String;
        }

        void FString::Dealloc()
        {
            FMemory::Free(String);
        }

        inline void FString::AllocString()
        {
            String = FMemory::MallocForType<wchar_t>(Length);
        }

        FString FCurlHttpRequest::GetURL()
        {
            return ((FString & (*&)(FCurlHttpRequest*, FString)) VTable[0])(this, FString());
        }

        int setupMemLeak = 0;
        void FCurlHttpRequest::RedirectRequest(bool bEOS)
        {
            if (!bEOS && !FCurlHttpRequest::SetURLIdx)
                InitializeURLIndex();
            else if (++setupMemLeak == 5 && FixMemLeak)
            {
                constexpr static auto pattern = Tellurium::Patchfinder::Pattern<"48 89 5C 24 ?? 57 48 83 EC ?? 48 8B 01 4C 8B C2 48 8D 54 24 ? 48 8B D9 FF 50 30">();
                constexpr static auto pattern2 = Tellurium::Patchfinder::Pattern<"48 8B 01 4C 8D 41 08 48 FF 60 20">();

                auto MemLeakPatch = pattern.Scan();

                if (!MemLeakPatch)
                    MemLeakPatch = pattern2.Scan();

                if (MemLeakPatch)
                {
                    DWORD oldProt;
                    VirtualProtect(LPVOID(MemLeakPatch), 1, PAGE_EXECUTE_READWRITE, &oldProt);

                    *(uint8_t*)MemLeakPatch = 0xC3;

                    VirtualProtect(LPVOID(MemLeakPatch), 1, oldProt, &oldProt);
                }
            }

            auto URL = GetURL();
            Tellurium::URL TelluriumURL = URL;

            if (Tellurium::Redirection::ShouldRedirect(TelluriumURL))
            {
                bool found = false;

                if (hostMap.size() != 0)
                {
                    for (const auto& [d, u] : hostMap)
                    {
                        if (TelluriumURL.Domain.find(d.c_str()) != Tellurium::URL::StrType::npos)
                        {
                            auto host = Tellurium::Unreal::FString::Construct(u.c_str());
                            TelluriumURL.SetHost(host);
                            found = true;
                            break;
                        }
                    }
                }

                if (pathMap.size() != 0 && !found)
                {
                    for (const auto& [p, u] : pathMap)
                    {
                        if (TelluriumURL.Path.find(p.c_str()) != Tellurium::URL::StrType::npos)
                        {
                            auto host = Tellurium::Unreal::FString::Construct(u.c_str());
                            TelluriumURL.SetHost(host);
                            found = true;
                            break;
                        }
                    }
                }

                if (!found)
                    TelluriumURL.SetHost(backend);

#if WITH_SOCKET
                if (!bEOS)
                {
                    auto& SetHeader = ((void (*&)(Tellurium::Unreal::FCurlHttpRequest*, Tellurium::Unreal::FString,
                        Tellurium::Unreal::FString))VTable[FCurlHttpRequest::SetURLIdx + 6 + (FortniteCL >= 27233190)]);

                    SetHeader(this, _(L"X-Arc-Client"), Config.ClientID.c_str());
                    SetHeader(this, _(L"X-Arc-Auth"), ArcToken.c_str());
                }
#endif
                static bool bSetupEngine = false;
                static bool bLateInit = false;
                if (!bSetupEngine && wcscmp(TelluriumURL.Path, _(L"/account/api/oauth/sessions/kill")) == 0)
                {
                    bSetupEngine = true;

                    if (FortniteCL < 15685441)
                    {
                        for (auto& EngineInitter : EngineInits)
                            EngineInitter();
                    }

                    auto Kitty = []()
                    {

                        /*uint64_t GObjects = 0;
                        if (FortniteCL >= 4204761)
                        {
                            GObjects = Offsets::GObjectsChunked = Memcury::Scanner::FindPattern(FortniteCL <= 4461277 ? "48 8B 05 ? ? ? ? 48 8B 0C C8 48 8D 04 D1" : "48 8B 05 ?
                        ? ? ? 48 8B 0C C8 48 8B 04 D1") .RelativeOffset(3) .Get();
                        }
                        else
                        {
                            auto Addr = Memcury::Scanner::FindPattern("48 8B 05 ? ? ? ? 48 8D 14 C8 EB 03 49 8B D6 8B 42 08 C1 E8 1D A8 01 0F 85 ? ? ? ? F7 86 ? ? ? ? ? ? ? ?",
                        false); if (!Addr.Get()) Addr = Memcury::Scanner::FindPattern("48 8B 05 ? ? ? ? 48 8D 1C C8 81 4B ? ? ? ? ? 49 63 76 30", false);

                            GObjects = Offsets::GObjectsUnchunked = Addr.RelativeOffset(3).Get();
                        }
                        Offsets::GRealObjects = *(uint64_t*)GObjects;

                        auto Key = uint64_t(rand()) << 48 | uint64_t(rand()) << 32 | uint64_t(rand()) << 16 | rand();
                        Key ^= uint64_t(&GObjects);*/
                        Freeze();
                        auto World = UWorld::GetWorld();
                        std::vector<uint64_t> WorldPtrs;

                        auto data = GetSect(gameBase, _(".data"));

                        auto _scanBytes = (uint8_t*)(__int64(gameBase) + data->VirtualAddress);
                        auto _sizeOfImage = data->Misc.VirtualSize;

                        for (auto i = 0ul; i < _sizeOfImage - 8; i += alignof(uint64_t))
                        {
                            if (*(uint64_t*)(_scanBytes + i) == __int64(World))
                            {
                                WorldPtrs.push_back(__int64(_scanBytes + i));
                                // break;
                            }
                        }

                        auto text = GetSect(gameBase, _(".text"));

                        auto scanBytes = (uint8_t*)(__int64(gameBase) + text->VirtualAddress);
                        auto sizeOfImage = text->Misc.VirtualSize;
                        if (WorldPtrs.size() > 0)
                        {
                            for (auto& GWorld : WorldPtrs)
                            {
                                auto NewWorld = GetShcRegion((void*)GWorld);
                                memcpy(NewWorld, (void*)GWorld, 8);
                                std::map<uint16_t, void*> Handlers;
                                for (auto i = 0ul; i < sizeOfImage - 7; ++i)
                                {
                                    if (((scanBytes[i] & 0xf8) == 0x48
                                            && (scanBytes[i + 1] == 0x8B || scanBytes[i + 1] == 0x89 || scanBytes[i + 1] == 0x83 || (scanBytes[i + 1] & 0xF8) == 0x38))
                                        || (scanBytes[i] == 0x0F && (scanBytes[i + 1] == 0x45 || scanBytes[i + 1] == 0x44)))
                                    {
                                        if (Memcury::PE::Address(&scanBytes[i]).RelativeOffset(3).GetAs<void*>() == (void*)GWorld)
                                        {
                                            Patch<uint32_t>(__int64(scanBytes + i + 3), uint32_t(__int64(NewWorld) - __int64(scanBytes + i + 7)));
                                            FlushInstructionCache(GetCurrentProcess(), scanBytes + i + 3, 4);
                                        }
                                    }
                                    else if (scanBytes[i] == 0x83)
                                    {
                                        if (Memcury::PE::Address(&scanBytes[i]).RelativeOffset(2, 1).GetAs<void*>() == (void*)GWorld)
                                        {
                                            Patch<uint32_t>(__int64(scanBytes + i + 2), uint32_t(__int64(NewWorld) - __int64(scanBytes + i + 7)));
                                            FlushInstructionCache(GetCurrentProcess(), scanBytes + i + 2, 4);
                                        }
                                    }
                                }
                                *(uint64_t*)GWorld = 0x0;
                            }
                        }
                        Unfreeze();

                        ExitThread(0);
                        while (true)
                            Sleep(1000);
                    };

                    CreateThread(0, 0, LPTHREAD_START_ROUTINE((void (*)())Kitty), 0, 0, 0);
                }

                if (!bLateInit && wcscmp(TelluriumURL.Path, _(L"/fortnite/api/calendar/v1/timeline")) == 0)
                {
                    bLateInit = true;
                    auto Broooo = []()
                    {
                        for (auto& LateInitter : LateInits)
                            LateInitter();

                        ExitThread(0);
                        while (true)
                            Sleep(1000);
                    };

                    CreateThread(0, 0, LPTHREAD_START_ROUTINE((void(*)())Broooo), 0, 0, 0);
                }

                Tellurium::Unreal::FString str = TelluriumURL;
                ((void (*&)(Tellurium::Unreal::FCurlHttpRequest*, Tellurium::Unreal::FString))VTable[bEOS ? 10 : FCurlHttpRequest::SetURLIdx])(this, str);
                str.Dealloc();

                UseBackendParam ? TelluriumURL.Dealloc() : TelluriumURL.DeallocPathQuery();
            }
            else
                TelluriumURL.Dealloc();

            URL.Dealloc();
        }

    }
}

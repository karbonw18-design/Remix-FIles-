#pragma once
#include "../../LazyImporter.h"
#include "../../StrCrypt.h"
#include "../../Utils.h"
#include "../../pch.h"
#include <bitset>

namespace ProjectArc
{
    namespace Bootstrapper
    {
        inline const char* exePath = nullptr;
        inline std::wstring GameFolder;
        inline LPVOID gameBase = nullptr;
        inline SIZE_T gameSize = 0;
        inline uint32_t gameTlsIndex = 0;
        inline bool bSetupGame = false;
    }

    namespace Types
    {
        struct LIST_ENTRY_T
        {
            LIST_ENTRY_T* Flink;
            LIST_ENTRY_T* Blink;
        };

        struct UNICODE_STRING_T
        {
            unsigned short Length;
            unsigned short MaximumLength;
            wchar_t* Buffer;
        };

        struct PEB_LDR_DATA_T
        {
            unsigned long Length;
            unsigned long Initialized;
            const char* SsHandle;
            LIST_ENTRY_T InLoadOrderModuleList;
        };

        struct PEB_T
        {
            BOOLEAN InheritedAddressSpace;
            BOOLEAN ReadImageFileExecOptions;
            BOOLEAN BeingDebugged;
            BOOLEAN BitField;
            PVOID Mutant;
            PVOID ImageBaseAddress; // Base address of the loaded image
            PEB_LDR_DATA_T* Ldr; // Pointer to the loader data
            PRTL_USER_PROCESS_PARAMETERS ProcessParameters;
            PVOID SubSystemData;
            PVOID ProcessHeap;
            PVOID FastPebLock;
            PVOID AtlThunkSListPtr;
            PVOID IFEOKey;
            ULONG CrossProcessFlags;
            PVOID KernelCallbackTable;
            ULONG SystemReserved;
            ULONG AtlThunkSListPtr32;
            PVOID ApiSetMap;
            ULONG TlsExpansionCounter;
            PVOID TlsBitmap;
            ULONG TlsBitmapBits[2];
            PVOID ReadOnlySharedMemoryBase;
            PVOID HotpatchInformation;
            PVOID* TlsExpansionSlots; // TLS slots for tls index >= 64
        };

        struct LDR_DATA_TABLE_ENTRY_T
        {
            LIST_ENTRY_T InLoadOrderLinks;
            LIST_ENTRY_T InMemoryOrderLinks;
            LIST_ENTRY_T InInitializationOrderLinks;
            const char* DllBase;
            const char* EntryPoint;
            union
            {
                unsigned long SizeOfImage;
                const char* _dummy;
            };
            UNICODE_STRING_T FullDllName;
            UNICODE_STRING_T BaseDllName;
        };

        struct TEB_T
        {
            NT_TIB NtTib;
            PVOID EnvironmentPointer;
            CLIENT_ID ClientId;
            PVOID ActiveRpcHandle;
            VOID** ThreadLocalStoragePointer; // TLS slots for tls index < 64
            PPEB ProcessEnvironmentBlock;
            // other fields omitted
        };
    }
}
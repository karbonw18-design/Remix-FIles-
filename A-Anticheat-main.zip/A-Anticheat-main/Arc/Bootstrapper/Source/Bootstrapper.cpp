#include "pch.h"
#include "../../AntiCheat/Headers/Shared.h"
#include "../../Tellurium/Headers/Options.h"
#include "../Headers/Configuration.h"
#include "../Headers/CrashReporter.h"
#include "../Headers/Hooks.h"
#include "../Headers/Shared.h"
#include "../Headers/TLS.h"
#include "StrCrypt.h"
#include <Psapi.h>
#include <ShellScalingApi.h>
#include <minwinbase.h>
#include <processthreadsapi.h>
#include <shellapi.h>
#include <gdiplus.h>
#include <Shlwapi.h>
#include "../Headers/ArcLogo.h"
#pragma comment(lib, "shcore.lib")
#pragma comment(lib, "gdiplus.lib")
#include <thread>
#include <dwmapi.h>
#include "../../Tellurium/Headers/Hooks.h"
#include <vmaware.hpp>

using namespace Gdiplus;
using namespace ProjectArc::Bootstrapper;
using namespace ProjectArc::Types;

enum EStrapperError
{
    Success = 0,
    FailedToFind = -1,
    InvalidFile = -2,
    FailedToAllocate = -3,
    FailedToFindToken = -4,
    FailedImport = -5,
    LaunchCheckFailed = -6,
};

#if !WITH_SOCKET
const char exe[] = "D:\\12.41\\FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe";
#endif

BOOL IsElevated()
{
    BOOL fRet = FALSE;
    HANDLE hToken = NULL;
    if (OpenProcessToken(_li(GetCurrentProcess)(), TOKEN_QUERY, &hToken))
    {
        TOKEN_ELEVATION Elevation;
        DWORD cbSize = sizeof(TOKEN_ELEVATION);
        if (_li(GetTokenInformation)(hToken, TokenElevation, &Elevation, sizeof(Elevation), &cbSize))
        {
            fRet = Elevation.TokenIsElevated;
        }
    }
    if (hToken)
    {
        CloseHandle(hToken);
    }
    return fRet;
}

int dotCount = 0;
DWORD lastDotUpdate = 0;
Image* bgImg = nullptr;
Image* ArcImg = nullptr;
std::wstring splashStatus = _(L"CONNECTING");

LRESULT CALLBACK SplashWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        auto __hdc = GetDC(hwnd);
        auto hdc = CreateCompatibleDC(__hdc);

        RECT rc;
        GetClientRect(hwnd, &rc);
        int width = rc.right - rc.left;
        int height = rc.bottom - rc.top;

        auto hBmp = CreateCompatibleBitmap(__hdc, width, height);
        SelectObject(hdc, hBmp);

        Graphics graphics(hdc);
        graphics.SetSmoothingMode(SmoothingModeAntiAlias);
        graphics.SetTextRenderingHint(TextRenderingHintAntiAlias);

        if (bgImg && bgImg->GetLastStatus() == Ok)
        {
            graphics.DrawImage(bgImg, 0, 0, width, height);
        }
        else
        {
            SolidBrush bgBrush(Color(255, 15, 15, 25));
            graphics.FillRectangle(&bgBrush, 0, 0, width, height);
        }

        graphics.DrawImage(ArcImg, 0, 0, 100, 100);

        //DWORD currentTime = GetTickCount();
        //if (currentTime - lastDotUpdate > 500)
        {
            dotCount = (dotCount + 1) % 4;
            //lastDotUpdate = currentTime;
        }

        std::wstring statusText = splashStatus;
        for (int i = 0; i < dotCount; i++)
        {
            statusText += L".";
        }

        FontFamily fontFamily(_(L"Bahnschrift"));
        Font statusFont(&fontFamily, 16, FontStyleRegular, UnitPoint);
        SolidBrush textBrush(Color(255, 255, 255, 255));



        if (errorText.size() > 0)
        {
            StringFormat centerFormat;
            centerFormat.SetAlignment(StringAlignmentCenter);
            centerFormat.SetLineAlignment(StringAlignmentCenter);

            SolidBrush transBrush(Color(200, 45, 45, 45));
            graphics.FillRectangle(&transBrush, 0, 0, width, height);

            RectF textRect((REAL)0, (REAL)0, (REAL)(width - 35), (REAL)(height - 25));
            graphics.DrawString(errorText.c_str(), -1, &statusFont, textRect, &centerFormat, &textBrush);
        }
        else
        {
            StringFormat rightFormat;
            rightFormat.SetAlignment(StringAlignmentFar);
            rightFormat.SetLineAlignment(StringAlignmentFar);

            RectF textRect((REAL)0, (REAL)0, (REAL)(width - 35), (REAL)(height - 25));
            graphics.DrawString(statusText.c_str(), -1, &statusFont, textRect, &rightFormat, &textBrush);
        }

        HDC _hdc = BeginPaint(hwnd, &ps);
        BitBlt(_hdc, 0, 0, width, height, hdc, 0, 0, SRCCOPY);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_CLOSE:
        //DestroyWindow(hwnd);
        if (!bDisableSplashClose)
            TerminateProcess(GetCurrentProcess(), 0);
        else
            DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        KillTimer(hwnd, 1);
        if (bgImg)
        {
            delete bgImg;
            bgImg = nullptr;
        }
        //PostQuitMessage(0);
        break;
    case WM_ERASEBKGND:
        return true;
    case WM_NCHITTEST:
        auto hit = DefWindowProcA(hwnd, msg, wParam, lParam);

        if (hit == HTCLIENT)
            return HTCAPTION;

        return hit;
    }

    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

void TimerProc(HWND hWnd, UINT, UINT_PTR, DWORD)
{
    InvalidateRect(hWnd, NULL, FALSE);
}

void VerifyModuleSignatures()
{
    auto PEB = (li::detail::win::PEB_T*)__readgsqword(0x60);
    auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
    auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

    std::vector<HMODULE> LibrariesToFree;
    do
    {
        size_t v = 0;
        if (Entry->FullDllName.Buffer != nullptr && Entry->DllBase != __ThisBase && Entry->FullDllName.Length > 0 && Entry->BaseDllName.Length > 0 && Entry->BaseDllName.Buffer[0] != 0
            && !VerifyEmbeddedSignature(Entry->FullDllName.Buffer))
        {
            char fileName8[MAX_PATH];
            for (int i = 0; i < MAX_PATH; i++)
            {
                fileName8[i] = (char)Entry->FullDllName.Buffer[i];
            }

            json DetectionInfo;

            DetectionInfo[_("type")] = _("detection");
            DetectionInfo[_("code")] = UnsignedDLLLoaded;
            DetectionInfo[_("ban")] = false;
            DetectionInfo[_("close")] = false;
            DetectionInfo[_("info")] = std::string(_("Pre-Hook, File path: ")) + fileName8;

            SendDetectionReport(DetectionInfo);
            LibrariesToFree.push_back(HMODULE(Entry->DllBase));
            continue;
        }
    }
    while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != nullptr && Entry != Head);

    for (auto& Library : LibrariesToFree)
    {
        FreeLibrary(Library);

        auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
        auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
        do
        {
            if (Entry->DllBase == (const char*)Library)
            {
                *(uint64_t*)_AddressOfReturnAddress() = 0;
                _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
                return;
            }
        }
        while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != nullptr && Entry != Head);
    }

    DWORD pid = GetCurrentProcessId();

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    THREADENTRY32 te { sizeof(THREADENTRY32) };

    if (Thread32First(hSnap, &te))
    {
        do
        {
            if (te.th32OwnerProcessID != pid)
                continue;
            
            HANDLE hThread = OpenThread(THREAD_QUERY_INFORMATION, FALSE, te.th32ThreadID);
            if (!hThread)
                continue;

            uintptr_t startAddr = 0;
            DWORD outLen = 0;
            NtQueryInformationThread(hThread, (THREADINFOCLASS)9, &startAddr, sizeof(startAddr), &outLen);

            auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
            auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
            bool bFound = false;
            do
            {
                if (uintptr_t(Entry->DllBase) <= startAddr && startAddr < uintptr_t(Entry->DllBase) + Entry->SizeOfImage)
                {
                    bFound = true;
                    break;
                }
            }
            while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != nullptr && Entry != Head);

            if (!bFound)
            {

                json DetectionInfo;

                DetectionInfo[_("type")] = _("detection");
                DetectionInfo[_("code")] = BadThreadCreate;
                DetectionInfo[_("ban")] = false;
                DetectionInfo[_("close")] = true;
                DetectionInfo[_("info")] = std::string(_("Thread start address: ")) + std::to_string(startAddr);

                SendDetectionReport(DetectionInfo);
                return;
            }
            CloseHandle(hThread);
        }
        while (Thread32Next(hSnap, &te));
    }

    CloseHandle(hSnap);
}

void FIC__Init()
{
    Hook(LI_FN(FlushInstructionCache).get(), FlushInstructionCacheHook, FlushInstructionCacheOG);
}

bool bSplashInit = false;
#ifdef WITH_LOGS
int main()
#else
int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow)
#endif
{
#ifdef _DEBUG
    std::cout << "[test3] Registering crash reporter...\n";
    FCrashReporter::Register();

#else
    fuckIda;
#endif
#ifdef WITH_LOGS
    std::cout << "[Arc] Initializing...\n";
#endif
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\user32.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\advapi32.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\shell32.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\ncrypt.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\crypt32.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\dwmapi.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\shlwapi.dll"));

    AntiDebug__Init();
    /*auto kdmapperFile = _li(CreateFileW)(_(L"\\\\.\\Nal"), 0xC0000000, 3u, 0, 3u, 0, 0);

    if (__int64(kdmapperFile) > 0)
    {
        _li(MessageBoxA)(nullptr, _("Please restart your computer in order to play."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        // Erase();
        return LaunchCheckFailed;
    }*/

#if !WITH_LOGS
    std::string sCmdLine(lpCmdLine);
    auto NullrhiPos = sCmdLine.find(_("-nullrhi"));
    if (NullrhiPos != std::string::npos)
    {
        _li(MessageBoxA)(0, _("Failed to initialize! (#1)"), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return LaunchCheckFailed;
    }

    if (VM::detect())
    {
        MessageBoxA(nullptr, _("Virtual machines are not allowed."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return LaunchCheckFailed;
    }

    SYSTEM_CODEINTEGRITY_INFORMATION Integrity = { sizeof(SYSTEM_CODEINTEGRITY_INFORMATION), 0 };
    NTSTATUS status = _li(NtQuerySystemInformation)(SystemCodeIntegrityInformation, &Integrity, sizeof(Integrity), NULL);

    if (NT_SUCCESS(status) && (Integrity.CodeIntegrityOptions & 3) != 0x1)
    {
        MessageBoxA(nullptr, _("Please enable DSE/disable testsigning to play."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return LaunchCheckFailed;
    }
#endif

#if WITH_SOCKET && !WITH_LOGS
    if (!IsElevated())
    {
        char buffer[2048];
        GetModuleFileNameA(NULL, buffer, 2048);

        HINSTANCE hInstance = _li(ShellExecuteA)(NULL,
            _("runas"),
            buffer,
            lpCmdLine,
            NULL,
            SW_HIDE
        );
        return 0;
    }
#endif

    HANDLE hSemaphore = _li(CreateSemaphoreW)(NULL, 0, 1, _(L"Global\\ArcClient"));

    if (hSemaphore == NULL || GetLastError() == ERROR_ALREADY_EXISTS)
    {
        _li(MessageBoxA)(0, _("Another Arc client is already open!"), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return LaunchCheckFailed;
    }

    auto PEB = (PEB_T*)__readgsqword(0x60);

    __ThisBase = *(char**)(__int64(PEB) + 0x10);
    auto __ThisDosHeader = (IMAGE_DOS_HEADER*)__ThisBase;
    auto __ThisPeHeader = (IMAGE_NT_HEADERS*)(__int64(__ThisBase) + __ThisDosHeader->e_lfanew);
    __ThisSize = __ThisPeHeader->OptionalHeader.SizeOfImage;

    thisText = GetSect(__ThisBase, _(".text"));

    MinHook::MH_Initialize();
    // dumb bug fix
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\SHCore.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\AppxDeploymentClient.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\MrmCoreR.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\windows.storage.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\ole32.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\wintrust.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\d3dcompiler_47.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\winhttp.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\windows.ui.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\combase.dll"));
    _li(LoadLibraryA)(_("C:\\Windows\\System32\\nvml.dll"));
    Loader__Init();
    FIC__Init();

    /*HKEY hKey = {};
    auto openRes = _li(RegOpenKeyExA)(HKEY_LOCAL_MACHINE, _("SYSTEM\\CurrentControlSet\\Control\\CI\\Config"), 0, KEY_QUERY_VALUE, &hKey);

    if (!openRes) [[likely]]
    {
        DWORD VDCIEnabled;

        const wchar_t* value = _(L"VulnerableDriverBlocklistEnable");
        DWORD outSize = 4;

        auto lStatus = _li(RegQueryValueExW)(hKey, value, 0, NULL, (LPBYTE)&VDCIEnabled, &outSize);
        // free((void*)value);

        if (!lStatus && VDCIEnabled == 0) [[unlikely]]
        {
            MessageBoxA(nullptr, _("Please enable vulnerable driver blocklist and restart to play."), _("Arc"), MB_OK);
            return LaunchCheckFailed;
        }
    }*/

    auto CurrentPrc = _li(GetCurrentProcess)();

    /*unsigned char KernelDebugInfo = *(unsigned char*)0x7ffe02d4;
    DWORD dwProcessDebugFlags /*, dwProcessDebugPort* /, dwReturned;
    HANDLE hProcessDebugObject;

    NTSTATUS status;

    auto NtQueryInformationProcess_ = _li(NtQueryInformationProcess);

    if (IsHooked(NtQueryInformationProcess_))
        goto _ret;
    //// status = NtQueryInformationProcess_(CurrentProcessHandle, ProcessDebugPort, &dwProcessDebugPort, sizeof(DWORD), &dwReturned);

    status = NtQueryInformationProcess_(CurrentPrc, (PROCESSINFOCLASS)0x1f, &dwProcessDebugFlags, sizeof(DWORD), &dwReturned);

    status = NtQueryInformationProcess_(CurrentPrc, (PROCESSINFOCLASS)0x1e, &hProcessDebugObject, sizeof(HANDLE), &dwReturned);

    if (PEB->BeingDebugged /* || dwProcessDebugPort == -1* / || dwProcessDebugFlags == 0 || hProcessDebugObject != 0 || (KernelDebugInfo & 0x01) || (KernelDebugInfo & 0x02))
    {
    _ret:
        return DebuggerLoaded;
    }*/

    srand((uint32_t)time(0));

    // ts is so scuffed
#if WITH_SOCKET
    LoadConfiguration();

    if (Config.Executable.empty() || Config.ClientID.empty())
    {
        _li(MessageBoxA)(0, _("Failed to read configuration!\n\nIf you are the developer, please check your config."), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
        return false;
    }

    char buffer[2048];
    GetModuleFileNameA(NULL, buffer, 2048);
    std::filesystem::path exeDir = std::filesystem::path(buffer).parent_path();

    if (Config.Splash.size() > 0)
    {
        std::filesystem::path imagePath = exeDir / Config.Splash;

        if (std::filesystem::exists(imagePath))
        {
            auto SplashThr =
                []()
                {
                    GdiplusStartupInput gdiplusStartupInput;
                    ULONG_PTR gdiplusToken;
                    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

                    std::filesystem::path exeDir = std::filesystem::path(__argv[0]).parent_path();
                    std::filesystem::path imagePath = exeDir / Config.Splash;
                    bgImg = Image::FromFile(imagePath.c_str());

                    IStream* pStream = _li(SHCreateMemStream)((BYTE*)ArcLogo, sizeof(ArcLogo));
                    ArcImg = Image::FromStream(pStream, false);
                    pStream->Release();

                    WNDCLASSEXA wc = { sizeof(WNDCLASSEXA) };
                    wc.lpfnWndProc = SplashWndProc;
                    wc.hInstance = HINSTANCE(__ThisBase);
                    wc.lpszClassName = _("ArcSplashScreen");
                    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
                    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);

                    RegisterClassExA(&wc);

                    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
                    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
                    int windowWidth = (int)min(bgImg->GetWidth(), screenWidth * .7);
                    int windowHeight = (int)min(bgImg->GetHeight(), screenHeight * .7);
                    int x = (screenWidth - windowWidth) / 2;
                    int y = (screenHeight - windowHeight) / 2;

                    SplashHWnd = CreateWindowExA(0, _("ArcSplashScreen"), _("Arc"), WS_POPUP, x, y, windowWidth, windowHeight, NULL, NULL, HINSTANCE(__ThisBase), NULL);

                    DWM_WINDOW_CORNER_PREFERENCE preference = DWMWCP_ROUND;
                    _li(DwmSetWindowAttribute)(SplashHWnd, DWMWA_WINDOW_CORNER_PREFERENCE, &preference, sizeof(preference));

                    SetTimer(SplashHWnd, 1, 1000, TimerProc);

                    ShowWindow(SplashHWnd, SW_SHOW);
                    //SetWindowPos(SplashHWnd, HWND_TOPMOST, x, y, windowWidth, windowHeight, SWP_SHOWWINDOW);
                    //UpdateWindow(SplashHWnd);

                    SendMessageA(SplashHWnd, WM_SYSCOMMAND, SC_RESTORE, 0);
                    SetForegroundWindow(SplashHWnd);
                    SetActiveWindow(SplashHWnd);
                    SetWindowPos(SplashHWnd, HWND_TOP, 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOMOVE | SWP_NOSIZE);
                    RedrawWindow(SplashHWnd, NULL, 0, RDW_FRAME | RDW_INVALIDATE | RDW_ALLCHILDREN);

                    //SetWindowPos(SplashHWnd, HWND_TOP, x, y, windowWidth, windowHeight, SWP_SHOWWINDOW);
                    bSplashInit = true;

                    MSG msg;
                    while (GetMessageA(&msg, NULL, 0, 0))
                    {
                        TranslateMessage(&msg);
                        DispatchMessageA(&msg);
                    }

                    GdiplusShutdown(gdiplusToken);
                    ExitThread(0);
                };

            CreateThread(0, 0, (LPTHREAD_START_ROUTINE)(void(*)())SplashThr, 0, 0, 0);

            while (!bSplashInit)
                Sleep(10);
        }
    }
    // #if false
    std::filesystem::path p = exeDir / _("..") / Config.Executable;
    p = p.lexically_normal();
    std::string tmp = p.string();
    std::replace(tmp.begin(), tmp.end(), '/', '\\');
    ProjectArc::Bootstrapper::exePath = tmp.c_str();

    std::string exeStr(ProjectArc::Bootstrapper::exePath);
    std::wstring widePath(exeStr.begin(), exeStr.end());

    GameFolder = widePath.substr(0, widePath.rfind(L'\\'));

    if (!InitSocket())
        return 0;

    while (!bReadyToLaunch)
        Sleep(10);

    splashStatus = _(L"INITIALIZING");
    InvalidateRect(SplashHWnd, NULL, FALSE);
#else
    ProjectArc::Bootstrapper::exePath = exe;

    std::string exeStr(ProjectArc::Bootstrapper::exePath);
    std::wstring widePath(exeStr.begin(), exeStr.end());

    ProjectArc::Bootstrapper::GameFolder = widePath.substr(0, widePath.rfind(L'\\'));
#endif
    VerifyModuleSignatures();

    // ADD_IMPORT_HOOK(GetModuleHandleW, Test);

    std::ifstream exeFile(ProjectArc::Bootstrapper::exePath, std::ios::binary | std::ios::ate);
    if (!exeFile)
    {
#if WITH_SOCKET
        std::string errorMsg = std::string(_("Failed to initialize!\n\nCould not find the application at:\n"))
            + (ProjectArc::Bootstrapper::exePath ? ProjectArc::Bootstrapper::exePath : _("unknown path"))
            + _("\n\nIf you are the developer, please check your config.");
#else
        std::string errorMsg = std::string(_("Failed to initialize!\n\nCould not find the application at:\n"))
            + (ProjectArc::Bootstrapper::exePath ? ProjectArc::Bootstrapper::exePath : _("unknown path"));
#endif
        if (SplashHWnd)
        {
            errorText = _(L"Failed to find game executable!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd, errorMsg.c_str(), _("Arc"), MB_OK | MB_TOPMOST);
        return EStrapperError::FailedToFind;
    }

    auto size = exeFile.tellg();
    if (size < 0x1000)
    {
        if (SplashHWnd)
        {
            errorText = _(L"Game file is corrupted!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd, _("Game file is corrupted!\n\nPlease obtain a new copy in order to play."), _("Arc"), MB_OK | MB_TOPMOST);
        return EStrapperError::InvalidFile;
    }

    // BYTE* gameBytes = new BYTE[(UINT_PTR)size];
    auto peHeaderSpace = VirtualAlloc(0, 0x1000, MEM_COMMIT, PAGE_READWRITE);

    exeFile.seekg(0, std::ios::beg);
    exeFile.read((char*)peHeaderSpace, 0x1000);

    DWORD og;
    VirtualProtect(peHeaderSpace, 0x1000, PAGE_READONLY, &og);

    auto dosHeader = (IMAGE_DOS_HEADER*)peHeaderSpace;
    if (dosHeader->e_magic != 0x5A4D)
    {
        if (SplashHWnd)
        {
            errorText = _(L"Game file is corrupted!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd, _("Game file is corrupted!\n\nPlease obtain a new copy in order to play."), _("Arc"), MB_OK | MB_TOPMOST);
        return EStrapperError::FailedToFind;
    }

    auto peHeader = (IMAGE_NT_HEADERS*)(__int64(peHeaderSpace) + dosHeader->e_lfanew);
    auto bASLREnabled = (peHeader->OptionalHeader.DllCharacteristics & IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE) != 0;

#ifdef WITH_LOGS
    std::cout << "[Arc] ImageSize: 0x" << std::hex << peHeader->OptionalHeader.SizeOfImage << "\n";
#endif
    gameSize = peHeader->OptionalHeader.SizeOfImage;
    gameBase = VirtualAlloc(bASLREnabled ? 0 : (void*)peHeader->OptionalHeader.ImageBase, gameSize + (rand() * 3), MEM_RESERVE, PAGE_NOACCESS);
    if (!gameBase)
    {
        if (SplashHWnd)
        {
            errorText = _(L"Failed to load!");
            InvalidateRect(SplashHWnd, NULL, FALSE);
        }
        _li(MessageBoxA)(SplashHWnd, _("Failed to allocate game space!"), _("Arc"), MB_OK | MB_TOPMOST);
        return EStrapperError::FailedToFind;
    }
#ifdef WITH_LOGS
    std::cout << "[Arc] ImageBase: 0x" << std::hex << uint64_t(gameBase) << "\n";
#endif

    IMAGE_SECTION_HEADER* section = IMAGE_FIRST_SECTION(peHeader);

    auto newPeSpace = VirtualAlloc(gameBase, 0x1000, MEM_COMMIT, PAGE_READWRITE);

    memset(newPeSpace, 0, 0x1000);
    memcpy(newPeSpace, peHeaderSpace, peHeader->OptionalHeader.SizeOfHeaders);
    auto _peHeader = (IMAGE_NT_HEADERS*)(__int64(newPeSpace) + dosHeader->e_lfanew);
    _peHeader->OptionalHeader.ImageBase = uint64_t(gameBase);

    gameText = GetSect(gameBase, _(".text"));

    for (UINT i = 0; i != peHeader->FileHeader.NumberOfSections; ++i, ++section)
    {
        if (section->SizeOfRawData)
        {
            auto bExecute = section->Characteristics & IMAGE_SCN_MEM_EXECUTE;

            /*auto sectSpace
                = */
            VirtualAlloc(LPVOID(__int64(gameBase) + section->VirtualAddress), section->Misc.VirtualSize, MEM_COMMIT, bExecute ? PAGE_EXECUTE_READWRITE : PAGE_READWRITE);
            auto sectSpace = __int64(gameBase) + section->VirtualAddress;
                // memset(sectSpace, 0, section->Misc.VirtualSize);

#ifdef WITH_LOGS
            std::cout << "[Arc] Section " << section->Name << " is at 0x" << std::hex << sectSpace << "\n";
#endif

            exeFile.seekg(section->PointerToRawData, std::ios::beg);
            exeFile.read((char*)sectSpace, section->SizeOfRawData);

            auto blud = (long)(section->Misc.VirtualSize - section->SizeOfRawData);
            if (blud > 0)
                memset((char*)sectSpace + section->SizeOfRawData, 0, blud);
        }
    }
    exeFile.close();

    BYTE* LocationDelta = (BYTE*)(__int64(gameBase) - peHeader->OptionalHeader.ImageBase);
    if (LocationDelta)
    {
        if (peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size)
        {
            auto* pRelocData = reinterpret_cast<IMAGE_BASE_RELOCATION*>(__int64(gameBase) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress);
            const auto* pRelocEnd
                = reinterpret_cast<IMAGE_BASE_RELOCATION*>(reinterpret_cast<uintptr_t>(pRelocData) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size);
            while (pRelocData < pRelocEnd && pRelocData->SizeOfBlock)
            {
                UINT AmountOfEntries = (pRelocData->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
                WORD* pRelativeInfo = reinterpret_cast<WORD*>(pRelocData + 1);

                for (UINT i = 0; i != AmountOfEntries; ++i, ++pRelativeInfo)
                {
                    UINT_PTR* pPatch = reinterpret_cast<UINT_PTR*>(__int64(gameBase) + pRelocData->VirtualAddress + ((*pRelativeInfo) & 0xFFF));

                    // DWORD oldProt;
                    // VirtualProtect(pPatch, 8, PAGE_READWRITE, &oldProt);
                    switch (*pRelativeInfo >> 0x0C)
                    {
                    case IMAGE_REL_BASED_DIR64:
                        *pPatch += reinterpret_cast<UINT_PTR>(LocationDelta);
                        break;
                    case IMAGE_REL_BASED_HIGHLOW:
                        *(DWORD*)pPatch += (DWORD) __int64(LocationDelta);
                        break;
                    case IMAGE_REL_BASED_HIGH:
                        *(WORD*)pPatch += HIWORD((DWORD) __int64(LocationDelta));
                        break;
                    case IMAGE_REL_BASED_LOW:
                        *(WORD*)pPatch += LOWORD((DWORD) __int64(LocationDelta));
                        break;
                    }
                    // VirtualProtect(pPatch, 8, oldProt, &oldProt);
                }
                pRelocData = reinterpret_cast<IMAGE_BASE_RELOCATION*>(reinterpret_cast<BYTE*>(pRelocData) + pRelocData->SizeOfBlock);
            }
        }
    }

    //AddDllDirectory(ProjectArc::Bootstrapper::GameFolder.c_str());
    //SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    //printf("%ls\n", PEB->ProcessParameters->ImagePathName.Buffer);
    SetCurrentDirectoryW(GameFolder.c_str());

    ImageBase = uint64_t(gameBase);
    Tellurium::PE::ImageBase = uint64_t(gameBase);
    /* auto FNVerPattern = Tellurium::Patchfinder::Pattern<"2B 00 2B 00 46 00 6F 00 72 00 74 00 6E 00 69 00 74 00 65 00 "
                                                        "2B 00 52 00 65 00 6C 00 65 00 61 00 73 00 65 00 2D 00",
        true>();
    auto FNVerString = FNVerPattern.Scan();*/

    uintptr_t FNVerString = 0;
    for (int i = 0; i < 5; i++)
    {
        FNVerString = Memcury::Scanner::FindPattern(_("2B 00 2B 00 46 00 6F 00 72 00 74 00 6E 00 69 00 74 00 65 00 "
                                                         "2B 00 52 00 65 00 6C 00 65 00 61 00 73 00 65 00 2D 00"),
            true, true, i)
                               .Get();

        if (!FNVerString)
            break;

        auto RestOfVer = std::wstring((wchar_t*)(FNVerString + 38));
        auto CLPos = RestOfVer.find(_(L"-CL-"));

        if (CLPos != std::wstring::npos)
        {
            FortniteCL = std::stoi(RestOfVer.substr(CLPos + 4));
            bIsFortnite = true;
            break;
        }
    }
    //bIsFortnite = FNVerString != 0;
    auto CurrentThr = _li(GetCurrentThread)();
    _li(DuplicateHandle)(CurrentPrc, CurrentThr, CurrentPrc, &hMainThread, DUPLICATE_SAME_ACCESS, false, DUPLICATE_SAME_ACCESS);
    SpawnThread(IntegrityThr, true, true);
    Hooks::Init();

    if (peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size)
    {
        auto* pImportDescr = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(__int64(gameBase) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
        while (pImportDescr->Name)
        {
            char* szMod = reinterpret_cast<char*>(__int64(gameBase) + pImportDescr->Name);
            HINSTANCE hDll = LoadLibraryA(szMod);

            if (!hDll)
            {
                std::string Error = _("Failed to find ");
                Error += szMod;
                Error += _("!\n\nReinstalling the game may fix this problem.\nAdditionally, check for Windows updates.");

                if (SplashHWnd)
                {
                    errorText = _(L"Failed to find dependency!");
                    InvalidateRect(SplashHWnd, NULL, FALSE);
                }
                _li(MessageBoxA)(SplashHWnd, Error.c_str(), _("Arc"), MB_OK | MB_TOPMOST);
                return FailedImport;
            }

            IMAGE_THUNK_DATA* pThunkRef = reinterpret_cast<IMAGE_THUNK_DATA*>(__int64(gameBase) + pImportDescr->OriginalFirstThunk);
            IMAGE_THUNK_DATA* pFuncRef = reinterpret_cast<IMAGE_THUNK_DATA*>(__int64(gameBase) + pImportDescr->FirstThunk);

            if (!pImportDescr->OriginalFirstThunk)
                pThunkRef = pFuncRef;

            for (; pThunkRef->u1.AddressOfData; ++pThunkRef, ++pFuncRef)
            {
                // DWORD oldProt;
                // VirtualProtect(pFuncRef, 8, PAGE_READWRITE, &oldProt);

                if (IMAGE_SNAP_BY_ORDINAL(pThunkRef->u1.Ordinal))
                {
                    pFuncRef->u1.Function = (ULONG_PTR)GetProcAddress(hDll, reinterpret_cast<char*>(pThunkRef->u1.Ordinal & 0xFFFF));

                    if (!pFuncRef->u1.Function)
                    {
                        std::string Error = _("Failed to find ordinal ");
                        Error += std::to_string(pThunkRef->u1.Ordinal & 0xFFFF);
                        Error += _(" in ");
                        Error += szMod;
                        Error += _("!\n\nReinstalling the game may fix this problem.\nAdditionally, check for Windows "
                                   "updates.");
                        if (SplashHWnd)
                        {
                            errorText = L"Failed to find dependency!";
                            InvalidateRect(SplashHWnd, NULL, FALSE);
                        }
                        _li(MessageBoxA)(SplashHWnd, Error.c_str(), _("Arc"), MB_OK | MB_TOPMOST);
                        return FailedImport;
                    }
                }
                else
                {

                    PIMAGE_IMPORT_BY_NAME importByName = (PIMAGE_IMPORT_BY_NAME)((DWORD_PTR)gameBase + pThunkRef->u1.AddressOfData);

                    auto _Hook = _Hooks[importByName->Name];

                    if (_Hook)
                        pFuncRef->u1.Function = (ULONG_PTR)_Hook;
                    else
                    {
                        pFuncRef->u1.Function = (ULONG_PTR)GetProcAddress(hDll, importByName->Name);

                        if (!pFuncRef->u1.Function)
                        {
                            std::string Error = _("Failed to find ");
                            Error += importByName->Name;
                            Error += _(" in ");
                            Error += szMod;
                            Error += _("!\n\nReinstalling the game may fix this problem.\nAdditionally, check for "
                                       "Windows updates.");
                            if (SplashHWnd)
                            {
                                errorText = _(L"Failed to find dependency!");
                                InvalidateRect(SplashHWnd, NULL, FALSE);
                            }
                            _li(MessageBoxA)(SplashHWnd, Error.c_str(), _("Arc"), MB_OK | MB_TOPMOST);
                            return FailedImport;
                        }
                    }
                }

                // VirtualProtect(pFuncRef, 8, oldProt, &oldProt);
            }
            ++pImportDescr;
        }
    }

    section = IMAGE_FIRST_SECTION(peHeader);

    for (UINT i = 0; i != peHeader->FileHeader.NumberOfSections; ++i, ++section)
    {
        auto sectSpace = LPVOID(__int64(gameBase) + section->VirtualAddress);

        if (section->SizeOfRawData)
        {
            auto prot = 0;

            auto bRead = section->Characteristics & IMAGE_SCN_MEM_READ;
            auto bWrite = section->Characteristics & IMAGE_SCN_MEM_WRITE;
            auto bExecute = section->Characteristics & IMAGE_SCN_MEM_EXECUTE;
            if (bExecute)
            {
                if (bRead && bWrite)
                    prot = PAGE_EXECUTE_READWRITE;
                else if (bRead)
                    prot = PAGE_EXECUTE_READ;
                else if (bWrite)
                    prot = PAGE_EXECUTE_WRITECOPY;
                else
                    prot = PAGE_EXECUTE;
            }
            else if (bWrite)
            {
                if (bRead)
                    prot = PAGE_READWRITE;
                else
                    prot = PAGE_WRITECOPY;
            }
            else if (bRead)
                prot = PAGE_READONLY;
            else
                prot = PAGE_NOACCESS;

            DWORD oldProt;
            VirtualProtect(sectSpace, section->Misc.VirtualSize, prot, &oldProt);
        }
    }

    auto baseName = widePath.substr(widePath.rfind(L'\\') + 1);
    if (FNVerString)
    {
        auto Entry = (LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
        auto Head = (LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

        if (FortniteCL < 4204761) // fixes guardit weirdness
        {
            do
            {
                if (__ThisBase == Entry->DllBase)
                {
                    Entry->BaseDllName.Buffer = (wchar_t*)baseName.c_str();
                    Entry->BaseDllName.MaximumLength = Entry->BaseDllName.Length = (unsigned short)baseName.length() * 2;
                    // Entry->FullDllName.Buffer = (wchar_t*)widePath.c_str();
                    // Entry->FullDllName.MaximumLength = Entry->FullDllName.Length = sizeof(exe) * 2 - 2;
                    Entry->DllBase = (const char*)gameBase;
                    // Entry->SizeOfImage = peHeader->OptionalHeader.SizeOfImage;
                    // Entry->EntryPoint = (const char*)entryPoint;
                    break;
                }
            }
            while ((Entry = (LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);
        }

        //*(void**)(__int64(PEB) + 0x10) = gameBase;
    }

    auto excep = peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
    if (excep.Size)
    {
        if (!RtlAddFunctionTable(
                reinterpret_cast<IMAGE_RUNTIME_FUNCTION_ENTRY*>(__int64(gameBase) + excep.VirtualAddress), excep.Size / sizeof(IMAGE_RUNTIME_FUNCTION_ENTRY), (DWORD64)gameBase))
        {
            goto _out;
        }
    }
_out:

    splashStatus = (L"STARTING GAME");
    InvalidateRect(SplashHWnd, NULL, FALSE);

    if (peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size)
    {
        auto* ourTLS = reinterpret_cast<IMAGE_TLS_DIRECTORY*>(__int64(__ThisBase) + __ThisPeHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress);
        auto ourTlsIndex = *(uint32_t*)ourTLS->AddressOfIndex;

        auto* pTLS = reinterpret_cast<IMAGE_TLS_DIRECTORY*>(__int64(gameBase) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress);

        if (pTLS->AddressOfIndex)
            *(uint32_t*)pTLS->AddressOfIndex = gameTlsIndex = ourTlsIndex;

        /*ImageBase = uint64_t(GetModuleHandleA(_("ntdll.dll")));
        auto LdrpFindTlsEntryP = Memcury::Scanner::FindPattern("48 39 48 38 74 ?? 48 8B 00");

        if (!LdrpFindTlsEntryP.IsValid())
            LdrpFindTlsEntryP = Memcury::Scanner::FindPattern("48 39 48 38 0F 85");

        if (!LdrpFindTlsEntryP.IsValid())
        {
            if (SplashHWnd)
            {
                errorText = _(L"Failed to initialize!");
                InvalidateRect(SplashHWnd, NULL, FALSE);
            }
            _li(MessageBoxA)(SplashHWnd, _("Failed to initialize (#2)!"), _("Arc"), MB_OK | MB_TOPMOST);
            return EStrapperError::FailedToFind;
        }
        
        auto LdrpFindTlsEntry_ = LdrpFindTlsEntryP.ScanFor({ 0x48, 0x8B, 0x05 }, false).Get();
        ImageBase = uint64_t(gameBase);

        auto Entry = (LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
        auto Head = (LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

        LDR_DATA_TABLE_ENTRY_T ldrDataTableEntry {};

        do
        {
            if (__ThisBase == Entry->DllBase)
                break;
        }
        while ((Entry = (LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);

        typedef struct _LDRP_TLS_DATA
        {
            LIST_ENTRY TlsLinks;
            IMAGE_TLS_DIRECTORY TlsDirectory;
        } LDRP_TLS_DATA, *PLDRP_TLS_DATA;

        auto LdrpFindTlsEntry = (_LDRP_TLS_DATA* (*)(LDR_DATA_TABLE_ENTRY_T*))LdrpFindTlsEntry_;

        auto tlsEntry = LdrpFindTlsEntry(Entry);
        tlsEntry->TlsDirectory = *pTLS;*/

        TLS::Allocate();

#ifdef WITH_LOGS
        printf("[Arc] TLS: Running callbacks\n");
#endif

        wipeFunction(WinMain);
        auto* pCallback = reinterpret_cast<PIMAGE_TLS_CALLBACK*>(pTLS->AddressOfCallBacks);
        for (; pCallback && *pCallback; ++pCallback)
            (*pCallback)(gameBase, DLL_PROCESS_ATTACH, nullptr);
    }
    else
        wipeFunction(WinMain);

    auto entryPoint = __int64(gameBase) + peHeader->OptionalHeader.AddressOfEntryPoint;
    if (bIsFortnite)
    {
        if (FortniteCL < 15685441)
        {
            CONTEXT thrCtx {};
            thrCtx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
            _li(GetThreadContext)(CurrentThr, &thrCtx);

            thrCtx.Dr0 = entryPoint + 9; // right after guardit onpack on v1
            thrCtx.Dr7 |= 0x1;
            _li(SetThreadContext)(CurrentThr, &thrCtx);
        }
        else
        {
            for (auto& UnpackInit : UnpackInits)
                UnpackInit();

            Tellurium::Hooks::Init();
        }
    }
    else
    {
        for (auto& UnpackInit : UnpackInits)
            UnpackInit();
    }
#ifdef WITH_LOGS
    std::cout << "[Arc] Setup game successfully!\n";
#endif
    VirtualFree(peHeaderSpace, 0, MEM_RELEASE);

    // CreateThread(0, 0, (LPTHREAD_START_ROUTINE) entryPoint, 0, 0, 0);

    bSetupGame = true;
    wipeFunction(WinMain);

    if ((!bIsFortnite || FortniteCL >= 15685441) && SplashHWnd)
    {
        bDisableSplashClose = true;
        PostMessageA(SplashHWnd, WM_CLOSE, 0, 0);
    }
    ((void (*)())entryPoint)();
    hMainThread = 0;

    return 0;
    // while (true) {}
}

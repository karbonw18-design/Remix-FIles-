@echo off
set __dir=%CD%
del /f /s /q build
mkdir build
clang -Xclang -emit-pch "%CD%\pch.cpp" -std=c++26 -I %CD% -c -o "%CD%/build/Arc.pch" -O2 -g -gcodeview -fpch-instantiate-templates -masm=intel -Wno-microsoft-cast
call :treeProcess
clang -E -xc -DRC_INVOKED Arc.rc -o build\Arc.rc
llvm-rc build\Arc.rc /Fobuild\Arc.res
clang -flto -fuse-ld=lld build\*.obj build\Arc.res -o build\Arc.exe -luser32 -g -Wl,/pdb:build\Arc.pdb -Wl,/MANIFEST:EMBED -Wl,/MANIFESTINPUT:app.manifest -Wl,/opt:ref -Wl,/opt:icf -lshell32 -ladvapi32 -lgdi32
goto :eof

:treeProcess
for %%f in (*.cpp) do clang -include-pch "%__dir%\build\Arc.pch" %CD%\%%f -std=c++26 -I %__dir% -c -o %__dir%/build/%%f.obj -g -gcodeview -O2 -fpch-instantiate-templates -masm=intel -Wno-microsoft-cast
for /D %%d in (*) do (
    cd %%d
    call :treeProcess
    cd ..
)
